/// Configuración global de SmartVentas.
///
/// Es el ÚNICO archivo que el estudiante debe cambiar para pasar del
/// modo DEMO (datos ficticios en memoria) al modo FIREBASE (datos reales).
class AppConfig {
  // Constructor privado: esta clase solo agrupa constantes,
  // no se crean objetos de ella.
  AppConfig._();

  /// false = MODO DEMO: no necesita Firebase, usa datos ficticios en memoria.
  /// true  = MODO FIREBASE: requiere haber ejecutado `flutterfire configure`
  ///         (Fase 5) y tener el archivo lib/firebase_options.dart.
  static const bool usarFirebase = true;

  /// Nombre de la tienda ficticia que aparece en la interfaz.
  static const String nombreTienda = 'TecnoAccesorios';

  /// Nombre de la aplicación.
  static const String nombreApp = 'SmartVentas';

  /// Símbolo de la moneda: soles peruanos.
  static const String simboloMoneda = 'S/';
}
