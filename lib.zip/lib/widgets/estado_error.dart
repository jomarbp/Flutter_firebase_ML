import 'package:flutter/material.dart';

/// Muestra un mensaje de error y, si se indica, un botón "Reintentar".
class EstadoError extends StatelessWidget {
  const EstadoError({
    super.key,
    required this.mensaje,
    this.alReintentar,
  });

  final String mensaje;

  /// Función que se ejecuta al tocar "Reintentar". Si es null, no hay botón.
  final VoidCallback? alReintentar;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline, size: 72, color: colores.error),
            const SizedBox(height: 16),
            Text(
              'Ocurrió un problema',
              style: textos.titleLarge,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              mensaje,
              style: textos.bodyMedium?.copyWith(
                color: colores.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            if (alReintentar != null) ...[
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: alReintentar,
                icon: const Icon(Icons.refresh),
                label: const Text('Reintentar'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
