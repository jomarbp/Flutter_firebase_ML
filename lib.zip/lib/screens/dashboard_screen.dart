import 'package:flutter/material.dart';

import 'package:smartventas/config.dart';
import 'package:smartventas/models/producto.dart';
import 'package:smartventas/models/venta.dart';
import 'package:smartventas/services/auth_service.dart';
import 'package:smartventas/services/producto_service.dart';
import 'package:smartventas/services/venta_service.dart';
import 'package:smartventas/utils/calculos_reportes.dart';
import 'package:smartventas/utils/formato.dart';
import 'package:smartventas/widgets/estado_error.dart';
import 'package:smartventas/widgets/etiqueta_origen_datos.dart';
import 'package:smartventas/widgets/grafico_barras.dart';
import 'package:smartventas/widgets/menu_usuario.dart';
import 'package:smartventas/widgets/tarjeta_indicador.dart';

/// Período que se resume en el Dashboard.
enum PeriodoDashboard {
  hoy('Hoy', 1),
  semana('7 días', 7),
  mes('30 días', 30),
  todo('Todo', null);

  const PeriodoDashboard(this.etiqueta, this.dias);
  final String etiqueta;

  /// null = sin límite de fechas.
  final int? dias;
}

/// Pantalla de Inicio: indicadores, ventas por día, más vendidos y stock bajo.
///
/// TODOS los números se calculan con utils/calculos_reportes.dart a partir
/// de las ventas y productos reales (o de demostración). Ninguno está
/// escrito a mano en los widgets.
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
    required this.usuario,
    required this.authService,
    required this.productoService,
    required this.ventaService,
  });

  final Usuario usuario;
  final AuthService authService;
  final ProductoService productoService;
  final VentaService ventaService;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Stream<List<Producto>> _productos;
  late Stream<List<Venta>> _ventas;
  PeriodoDashboard _periodo = PeriodoDashboard.mes;

  @override
  void initState() {
    super.initState();
    _suscribir();
  }

  void _suscribir() {
    _productos = widget.productoService.observarProductos();
    _ventas = widget.ventaService.observarVentas();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConfig.nombreApp),
        actions: [
          const EtiquetaOrigenDatos(),
          MenuUsuario(usuario: widget.usuario, authService: widget.authService),
          const SizedBox(width: 4),
        ],
      ),
      // Dos StreamBuilder anidados: uno para productos y otro para ventas.
      body: StreamBuilder<List<Producto>>(
        stream: _productos,
        builder: (context, productos) => StreamBuilder<List<Venta>>(
          stream: _ventas,
          builder: (context, ventas) {
            final error = productos.error ?? ventas.error;
            if (error != null) {
              return EstadoError(
                mensaje: 'No se pudieron cargar los datos.\n$error',
                alReintentar: () => setState(_suscribir),
              );
            }
            if (!productos.hasData || !ventas.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            return _construir(productos.data!, ventas.data!);
          },
        ),
      ),
    );
  }

  Widget _construir(List<Producto> productos, List<Venta> ventas) {
    final textos = Theme.of(context).textTheme;
    final colores = Theme.of(context).colorScheme;
    final hoy = DateTime.now();
    final dias = _periodo.dias;
    final desde = dias == null ? null : DateTime(hoy.year, hoy.month, hoy.day - dias + 1);

    final indicadores = IndicadoresDashboard.calcular(
      ventas: ventas,
      productos: productos,
      desde: desde,
      hasta: hoy,
    );
    final resumen = indicadores.resumen;
    final ventasPeriodo = ventasEnRango(ventas, desde: desde, hasta: hoy);

    // Gráfico: 7 días para "Hoy" y "7 días"; 30 días para los demás.
    final diasGrafico = (dias ?? 30) <= 7 ? 7 : 30;
    final porDia = ingresosPorDia(
      ventas,
      desde: DateTime(hoy.year, hoy.month, hoy.day - diasGrafico + 1),
      hasta: hoy,
    );
    final datosDia = [
      for (final e in porDia.entries)
        DatoGrafico(
          formatearDiaMes(e.key),
          e.value / 100,
          detalle: formatearFecha(e.key),
        ),
    ];
    final top = rankingPorUnidades(ventasPeriodo, limite: 5);
    final stockBajo = productosStockBajo(productos);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('${AppConfig.nombreTienda} · Hola, ${widget.usuario.nombre}',
            style: textos.titleMedium),
        const SizedBox(height: 4),
        Text('Resumen del negocio', style: textos.headlineSmall),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          children: [
            for (final p in PeriodoDashboard.values)
              ChoiceChip(
                label: Text(p.etiqueta),
                selected: _periodo == p,
                onSelected: (_) => setState(() => _periodo = p),
              ),
          ],
        ),
        const SizedBox(height: 12),
        GridView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 220,
            mainAxisExtent: 150,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
          ),
          children: [
            TarjetaIndicador(
              icono: Icons.payments_outlined,
              titulo: 'Ingresos por ventas',
              valor: formatearSoles(resumen.ingresosCentimos),
              detalle: _periodo.etiqueta,
            ),
            TarjetaIndicador(
              icono: Icons.receipt_outlined,
              titulo: 'Ventas registradas',
              valor: '${resumen.numeroVentas}',
              detalle: 'confirmadas',
            ),
            TarjetaIndicador(
              icono: Icons.shopping_bag_outlined,
              titulo: 'Unidades vendidas',
              valor: '${resumen.unidades}',
              detalle: _periodo.etiqueta,
            ),
            TarjetaIndicador(
              icono: Icons.inventory_2_outlined,
              titulo: 'Productos registrados',
              valor: '${indicadores.productosRegistrados}',
              detalle: 'activos',
            ),
            TarjetaIndicador(
              icono: Icons.warning_amber_outlined,
              titulo: 'Stock bajo',
              valor: '${indicadores.productosStockBajo}',
              detalle: indicadores.productosStockBajo == 0
                  ? 'todo en orden'
                  : 'por reponer',
              color: indicadores.productosStockBajo > 0 ? colores.error : null,
            ),
          ],
        ),
        if (resumen.numeroVentas == 0)
          const Card(
            margin: EdgeInsets.only(top: 12),
            child: ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('No hay ventas en este período'),
              subtitle: Text('Los indicadores de ventas muestran cero.'),
            ),
          ),
        const SizedBox(height: 16),
        _Seccion(
          titulo: 'Ingresos por día · últimos $diasGrafico días',
          child: GraficoBarras(
            datos: datosDia,
            formatearValor: formatearSolesDecimal,
            formatearEje: formatearSolesCorto,
            etiquetaCada: diasGrafico == 7 ? 1 : 5,
          ),
        ),
        _Seccion(
          titulo: 'Productos más vendidos · ${_periodo.etiqueta}',
          child: BarrasHorizontales(
            datos: [
              for (final p in top)
                DatoGrafico(p.nombre, p.unidades.toDouble(),
                    detalle: formatearSoles(p.ingresosCentimos)),
            ],
            formatearValor: (v) => '${v.toInt()} u.',
          ),
        ),
        _Seccion(
          titulo: 'Stock bajo (${stockBajo.length})',
          child: stockBajo.isEmpty
              ? const Text('Ningún producto está por debajo de su stock mínimo.')
              : Column(
                  children: [
                    for (final p in stockBajo.take(6))
                      ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        leading: Icon(Icons.warning_amber, color: colores.error),
                        title: Text(p.nombre),
                        trailing: Text('${p.stock} / mín. ${p.stockMinimo}'),
                      ),
                  ],
                ),
        ),
      ],
    );
  }
}

/// Tarjeta con título para cada bloque del Dashboard.
class _Seccion extends StatelessWidget {
  const _Seccion({required this.titulo, required this.child});

  final String titulo;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(titulo, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}
