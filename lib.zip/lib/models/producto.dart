import 'package:smartventas/models/conversion.dart';
import 'package:smartventas/utils/formato.dart';

/// Categorías permitidas. Se usan en el formulario y en los filtros.
const List<String> categoriasProducto = [
  'Periféricos',
  'Audio',
  'Cables',
  'Energía',
  'Almacenamiento',
  'Accesorios',
  'Otros',
];

/// Un producto de la tienda.
///
/// Es INMUTABLE: sus campos son `final`. Para "cambiar" un producto se
/// crea una copia con [copyWith]. Así se evitan cambios accidentales.
class Producto {
  const Producto({
    required this.id,
    required this.nombre,
    required this.categoria,
    required this.precioCentimos,
    required this.costoCentimos,
    required this.stock,
    required this.stockMinimo,
    required this.fechaCreacion,
    this.activo = true,
    this.tieneVentas = false,
    this.esDemo = false,
  });

  /// Identificador del documento (en Firestore: productos/{id}).
  final String id;
  final String nombre;
  final String categoria;

  /// Precio de venta en céntimos: S/ 49.90 → 4990.
  final int precioCentimos;

  /// Costo unitario en céntimos (lo que le cuesta a la tienda).
  final int costoCentimos;

  /// Unidades disponibles.
  final int stock;

  /// Si el stock llega a este número o menos, se considera "stock bajo".
  final int stockMinimo;

  final DateTime fechaCreacion;

  /// false = producto desactivado (no se puede vender, pero se conserva
  /// porque tiene ventas en el historial).
  final bool activo;

  /// true si alguna vez se vendió. Decide si se puede eliminar.
  final bool tieneVentas;

  /// true si es un dato ficticio de demostración.
  final bool esDemo;

  // ───────────── Valores calculados (getters) ─────────────

  bool get stockBajo => stock <= stockMinimo;
  bool get agotado => stock == 0;

  /// Ganancia bruta por unidad (puede ser negativa si el costo es mayor).
  int get margenUnitarioCentimos => precioCentimos - costoCentimos;

  // ───────────── Copias ─────────────

  Producto copyWith({
    String? id,
    String? nombre,
    String? categoria,
    int? precioCentimos,
    int? costoCentimos,
    int? stock,
    int? stockMinimo,
    DateTime? fechaCreacion,
    bool? activo,
    bool? tieneVentas,
    bool? esDemo,
  }) {
    return Producto(
      id: id ?? this.id,
      nombre: nombre ?? this.nombre,
      categoria: categoria ?? this.categoria,
      precioCentimos: precioCentimos ?? this.precioCentimos,
      costoCentimos: costoCentimos ?? this.costoCentimos,
      stock: stock ?? this.stock,
      stockMinimo: stockMinimo ?? this.stockMinimo,
      fechaCreacion: fechaCreacion ?? this.fechaCreacion,
      activo: activo ?? this.activo,
      tieneVentas: tieneVentas ?? this.tieneVentas,
      esDemo: esDemo ?? this.esDemo,
    );
  }

  // ───────────── Conversión para Firestore ─────────────

  /// Convierte el producto en un mapa para guardarlo en Firestore.
  /// El id NO se guarda dentro: es el nombre del documento.
  Map<String, dynamic> toMap() {
    return {
      'nombre': nombre,
      // Versión en minúsculas y sin tildes, útil para buscar.
      'nombreNormalizado': normalizarTexto(nombre),
      'categoria': categoria,
      'precioCentimos': precioCentimos,
      'costoCentimos': costoCentimos,
      'stock': stock,
      'stockMinimo': stockMinimo,
      // Firestore convierte DateTime en Timestamp automáticamente.
      'fechaCreacion': fechaCreacion,
      'activo': activo,
      'tieneVentas': tieneVentas,
      'esDemo': esDemo,
    };
  }

  /// Crea un producto a partir de un documento de Firestore.
  factory Producto.fromMap(String id, Map<String, dynamic> datos) {
    return Producto(
      id: id,
      nombre: datos['nombre'] as String? ?? '',
      categoria: datos['categoria'] as String? ?? 'Otros',
      precioCentimos: enteroDesdeValor(datos['precioCentimos']),
      costoCentimos: enteroDesdeValor(datos['costoCentimos']),
      stock: enteroDesdeValor(datos['stock']),
      stockMinimo: enteroDesdeValor(datos['stockMinimo']),
      fechaCreacion: fechaDesdeValor(datos['fechaCreacion']),
      activo: datos['activo'] as bool? ?? true,
      tieneVentas: datos['tieneVentas'] as bool? ?? false,
      esDemo: datos['esDemo'] as bool? ?? false,
    );
  }

  @override
  String toString() => 'Producto($id, $nombre, stock: $stock)';
}
