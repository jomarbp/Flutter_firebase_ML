import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:smartventas/services/excepciones.dart';

/// Roles de la app. El rol se guarda en Firestore: usuarios/{uid}.rol
enum Rol { admin, vendedor }

/// Usuario que inició sesión, con su rol.
class Usuario {
  const Usuario({
    required this.uid,
    required this.correo,
    required this.nombre,
    required this.rol,
  });

  final String uid;
  final String correo;
  final String nombre;
  final Rol rol;

  /// El administrador gestiona productos y anula ventas.
  bool get esAdmin => rol == Rol.admin;
}

/// CONTRATO del servicio de autenticación.
abstract class AuthService {
  /// Emite el usuario actual (o null si no hay sesión) y cada cambio.
  Stream<Usuario?> observarSesion();

  Future<Usuario> iniciarSesion(String correo, String contrasena);

  Future<void> cerrarSesion();

  /// true si la app pide iniciar sesión (modo Firebase).
  bool get requiereLogin;
}

// ─────────────────────────── MODO DEMO ───────────────────────────

/// En modo DEMO no hay login: siempre hay un administrador ficticio.
class DemoAuthService implements AuthService {
  static const usuarioDemo = Usuario(
    uid: 'demo',
    correo: 'demo@smartventas.local',
    nombre: 'Docente (demo)',
    rol: Rol.admin,
  );

  @override
  bool get requiereLogin => false;

  @override
  Stream<Usuario?> observarSesion() async* {
    yield usuarioDemo;
  }

  @override
  Future<Usuario> iniciarSesion(String correo, String contrasena) async =>
      usuarioDemo;

  @override
  Future<void> cerrarSesion() async {}
}

// ─────────────────────────── MODO FIREBASE ───────────────────────────

/// Inicio de sesión con Firebase Authentication (correo y contraseña).
///
/// Además de autenticarse, el usuario debe tener un documento
/// usuarios/{uid} con activo == true. Ese documento lo crea el
/// administrador (scripts/firestore_admin.py registrar-usuario), nunca la
/// app: así nadie puede darse a sí mismo el rol "admin".
class FirebaseAuthService implements AuthService {
  FirebaseAuthService({FirebaseAuth? auth, FirebaseFirestore? db})
      : _auth = auth ?? FirebaseAuth.instance,
        _db = db ?? FirebaseFirestore.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  @override
  bool get requiereLogin => true;

  /// Lee el perfil (rol) del usuario. Devuelve null si no está habilitado.
  Future<Usuario?> _cargarPerfil(User usuario) async {
    final documento = await _db.collection('usuarios').doc(usuario.uid).get();
    final datos = documento.data();
    if (datos == null || datos['activo'] != true) return null;

    return Usuario(
      uid: usuario.uid,
      correo: usuario.email ?? '',
      nombre: datos['nombre'] as String? ?? usuario.email ?? 'Usuario',
      rol: datos['rol'] == 'admin' ? Rol.admin : Rol.vendedor,
    );
  }

  @override
  Stream<Usuario?> observarSesion() {
    // authStateChanges emite cada vez que se inicia o cierra sesión.
    return _auth.authStateChanges().asyncMap((usuario) async {
      if (usuario == null) return null;
      try {
        return await _cargarPerfil(usuario);
      } on FirebaseException {
        return null; // sin permiso para leer el perfil → sin sesión válida
      }
    });
  }

  @override
  Future<Usuario> iniciarSesion(String correo, String contrasena) async {
    try {
      final credencial = await _auth.signInWithEmailAndPassword(
        email: correo.trim(),
        password: contrasena,
      );
      final perfil = await _cargarPerfil(credencial.user!);
      if (perfil == null) {
        await _auth.signOut();
        throw const PermisoDenegadoException(
          'Tu cuenta existe, pero no está habilitada en SmartVentas. '
          'Pide al administrador que te registre.',
        );
      }
      return perfil;
    } on FirebaseAuthException catch (error) {
      throw SmartVentasException(_traducirError(error.code));
    }
  }

  @override
  Future<void> cerrarSesion() => _auth.signOut();

  /// Mensajes en español para los códigos de error de Firebase Auth.
  static String _traducirError(String codigo) {
    return switch (codigo) {
      'invalid-email' => 'El correo no tiene un formato válido',
      'invalid-credential' ||
      'wrong-password' ||
      'user-not-found' =>
        'Correo o contraseña incorrectos',
      'user-disabled' => 'Esta cuenta fue deshabilitada',
      'too-many-requests' =>
        'Demasiados intentos. Espera unos minutos e intenta de nuevo',
      'network-request-failed' => 'Sin conexión a internet',
      _ => 'No se pudo iniciar sesión ($codigo)',
    };
  }
}
