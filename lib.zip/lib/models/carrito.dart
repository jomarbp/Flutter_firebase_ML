import 'dart:math';

import 'package:flutter/foundation.dart';

import 'package:smartventas/models/producto.dart';
import 'package:smartventas/utils/validaciones.dart';

/// Una línea del carrito: un producto y cuántas unidades se llevan.
class ItemCarrito {
  const ItemCarrito({required this.producto, required this.cantidad});

  final Producto producto;
  final int cantidad;

  /// Subtotal = precio actual del producto × cantidad (entero exacto).
  int get subtotalCentimos => producto.precioCentimos * cantidad;

  ItemCarrito copyWith({Producto? producto, int? cantidad}) => ItemCarrito(
        producto: producto ?? this.producto,
        cantidad: cantidad ?? this.cantidad,
      );
}

/// Carrito de la venta en curso.
///
/// Extiende [ChangeNotifier]: cada vez que cambia, llama a
/// notifyListeners() y la pantalla (con ListenableBuilder) se redibuja.
///
/// El carrito NO descuenta stock: solo anota lo que el cliente quiere.
/// El stock se descuenta en el servicio de ventas al CONFIRMAR.
///
/// Los métodos que pueden fallar devuelven:
///   • null     → se hizo el cambio
///   • un texto → el mensaje de error (no se cambió nada)
class Carrito extends ChangeNotifier {
  Carrito({String Function()? generarId})
      : _generarId = generarId ?? generarIdVenta {
    _ventaId = _generarId();
  }

  final String Function() _generarId;
  late String _ventaId;

  /// Líneas del carrito por id de producto (un producto = una línea).
  final Map<String, ItemCarrito> _items = {};

  // ───────────── Lectura ─────────────

  /// Llave de idempotencia de ESTA venta. Se mantiene igual mientras no se
  /// confirme con éxito: si el usuario toca dos veces "Confirmar" o
  /// reintenta tras un error de red, se envía el mismo id y el servicio
  /// no registra la venta dos veces.
  String get ventaId => _ventaId;

  List<ItemCarrito> get items => List.unmodifiable(_items.values);
  bool get estaVacio => _items.isEmpty;

  int get totalCentimos =>
      _items.values.fold(0, (suma, item) => suma + item.subtotalCentimos);

  int get unidades => _items.values.fold(0, (suma, item) => suma + item.cantidad);

  /// Unidades de un producto que ya están en el carrito.
  int cantidadDe(String productoId) => _items[productoId]?.cantidad ?? 0;

  /// Lo que el servicio necesita para registrar la venta: id → cantidad.
  Map<String, int> get cantidades =>
      {for (final item in _items.values) item.producto.id: item.cantidad};

  /// Avisos cuando el stock cambió después de agregar (por ejemplo, otro
  /// vendedor vendió las últimas unidades).
  List<String> get problemas => [
        for (final item in _items.values)
          if (!item.producto.activo)
            '"${item.producto.nombre}" ya no está disponible'
          else if (item.cantidad > item.producto.stock)
            'Solo quedan ${item.producto.stock} de "${item.producto.nombre}"',
      ];

  // ───────────── Cambios ─────────────

  /// Agrega [cantidad] unidades de [producto]. Si ya estaba, las suma.
  String? agregar(Producto producto, int cantidad) {
    if (!producto.activo) return '"${producto.nombre}" está desactivado';
    if (cantidad <= 0) return 'La cantidad debe ser mayor que cero';

    final yaEnCarrito = cantidadDe(producto.id);
    final total = yaEnCarrito + cantidad;
    if (total > producto.stock) {
      if (yaEnCarrito > 0) {
        return 'Ya tienes $yaEnCarrito en el carrito y solo hay '
            '${producto.stock} disponibles';
      }
      return validarCantidadVenta(cantidad, producto.stock);
    }

    _items[producto.id] = ItemCarrito(producto: producto, cantidad: total);
    notifyListeners();
    return null;
  }

  /// Cambia la cantidad de una línea por [nuevaCantidad].
  String? cambiarCantidad(String productoId, int nuevaCantidad) {
    final item = _items[productoId];
    if (item == null) return 'El producto no está en el carrito';

    final error = validarCantidadVenta(nuevaCantidad, item.producto.stock);
    if (error != null) return error;

    _items[productoId] = item.copyWith(cantidad: nuevaCantidad);
    notifyListeners();
    return null;
  }

  void quitar(String productoId) {
    if (_items.remove(productoId) != null) notifyListeners();
  }

  /// Vacía el carrito y prepara un id NUEVO para la siguiente venta.
  /// Se llama después de confirmar con éxito.
  void vaciar() {
    _items.clear();
    _ventaId = _generarId();
    notifyListeners();
  }

  /// Actualiza los datos de los productos (stock, precio, activo) con la
  /// lista más reciente del servicio. Si un producto se eliminó, la línea
  /// queda marcada como no disponible.
  void actualizarProductos(List<Producto> productosActuales) {
    if (_items.isEmpty) return;
    final porId = {for (final p in productosActuales) p.id: p};
    for (final id in _items.keys.toList()) {
      final item = _items[id]!;
      _items[id] = item.copyWith(
        producto: porId[id] ?? item.producto.copyWith(activo: false),
      );
    }
    notifyListeners();
  }
}

final Random _azar = Random.secure();

/// Id aleatorio de 20 caracteres, con el mismo formato que los ids
/// automáticos de Firestore.
String generarIdVenta() {
  const caracteres =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  return List.generate(
    20,
    (_) => caracteres[_azar.nextInt(caracteres.length)],
  ).join();
}
