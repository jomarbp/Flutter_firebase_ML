import 'package:smartventas/data/datos_demo.dart';
import 'package:smartventas/services/auth_service.dart';
import 'package:smartventas/services/memoria_service.dart';
import 'package:smartventas/services/producto_service.dart';
import 'package:smartventas/services/venta_service.dart';

/// Agrupa todos los servicios de la app en un solo objeto.
///
/// Se crea una vez en main.dart y se pasa a las pantallas por su
/// constructor. Así cada pantalla recibe lo que necesita sin usar
/// paquetes extra de "inyección de dependencias".
class Servicios {
  const Servicios({
    required this.productos,
    required this.ventas,
    required this.auth,
    required this.esFirebase,
  });

  final ProductoService productos;
  final VentaService ventas;
  final AuthService auth;

  /// true = datos reales de Firestore; false = datos ficticios en memoria.
  final bool esFirebase;

  /// Servicios del MODO DEMO: datos ficticios en memoria, sin login.
  ///
  /// [latencia] simula la demora de la red para que se vean los
  /// indicadores de carga (en las pruebas se usa Duration.zero).
  factory Servicios.demo({Duration latencia = Duration.zero}) {
    final hoy = DateTime.now();
    final productosDemo = crearProductosDemo(hoy);

    final productos = MemoriaProductoService(
      productosIniciales: productosDemo,
      latencia: latencia,
    );
    final ventas = MemoriaVentaService(
      productos: productos,
      ventasIniciales: crearVentasDemo(hoy, productosDemo),
      latencia: latencia,
    );
    return Servicios(
      productos: productos,
      ventas: ventas,
      auth: DemoAuthService(),
      esFirebase: false,
    );
  }

  /// Servicios del MODO FIREBASE. Requiere haber llamado antes a
  /// Firebase.initializeApp() (ver main.dart).
  factory Servicios.firebase() {
    return Servicios(
      productos: FirestoreProductoService(),
      ventas: FirestoreVentaService(),
      auth: FirebaseAuthService(),
      esFirebase: true,
    );
  }
}
