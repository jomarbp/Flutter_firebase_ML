import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:smartventas/models/producto.dart';
import 'package:smartventas/utils/formato.dart';
import 'package:smartventas/utils/validaciones.dart';

/// Formulario de producto. Se usa tanto para REGISTRAR como para EDITAR.
///
/// No guarda nada por sí mismo: cuando todo es válido, arma un Producto
/// "borrador" y se lo entrega a la pantalla mediante [alGuardar].
class FormularioProducto extends StatefulWidget {
  const FormularioProducto({
    super.key,
    required this.alGuardar,
    this.productoInicial,
    this.guardando = false,
  });

  /// null = producto nuevo; con valor = editar ese producto.
  final Producto? productoInicial;

  /// Recibe el producto armado con los datos del formulario.
  final void Function(Producto borrador) alGuardar;

  /// true mientras la pantalla está guardando: desactiva el botón.
  final bool guardando;

  @override
  State<FormularioProducto> createState() => _FormularioProductoState();
}

class _FormularioProductoState extends State<FormularioProducto> {
  /// Llave para pedirle al Form que valide todos sus campos.
  final _formKey = GlobalKey<FormState>();

  // Un controlador por campo de texto: guarda lo que escribe el usuario.
  late final TextEditingController _nombre;
  late final TextEditingController _precio;
  late final TextEditingController _costo;
  late final TextEditingController _stock;
  late final TextEditingController _stockMinimo;
  String? _categoria;

  @override
  void initState() {
    super.initState();
    final p = widget.productoInicial;
    _nombre = TextEditingController(text: p?.nombre ?? '');
    _precio = TextEditingController(
        text: p == null ? '' : centimosATexto(p.precioCentimos));
    _costo = TextEditingController(
        text: p == null ? '' : centimosATexto(p.costoCentimos));
    _stock = TextEditingController(text: p?.stock.toString() ?? '');
    _stockMinimo = TextEditingController(text: p?.stockMinimo.toString() ?? '');
    _categoria = p?.categoria;
  }

  @override
  void dispose() {
    // Los controladores se liberan para no desperdiciar memoria.
    _nombre.dispose();
    _precio.dispose();
    _costo.dispose();
    _stock.dispose();
    _stockMinimo.dispose();
    super.dispose();
  }

  void _enviar() {
    FocusScope.of(context).unfocus(); // oculta el teclado
    final esValido = _formKey.currentState?.validate() ?? false;
    if (!esValido) return;

    final base = widget.productoInicial;
    final borrador = Producto(
      id: base?.id ?? '',
      nombre: _nombre.text.trim(),
      categoria: _categoria!,
      // Los validadores ya comprobaron que estos textos son correctos.
      precioCentimos: textoACentimos(_precio.text)!,
      costoCentimos: textoACentimos(_costo.text)!,
      stock: int.parse(_stock.text.trim()),
      stockMinimo: int.parse(_stockMinimo.text.trim()),
      fechaCreacion: base?.fechaCreacion ?? DateTime.now(),
      activo: base?.activo ?? true,
      tieneVentas: base?.tieneVentas ?? false,
      esDemo: base?.esDemo ?? false,
    );
    widget.alGuardar(borrador);
  }

  @override
  Widget build(BuildContext context) {
    final esNuevo = widget.productoInicial == null;

    // Solo dígitos, punto y coma en los importes.
    final soloImporte = [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))];
    // Solo dígitos en las cantidades: así es imposible escribir "-".
    final soloEnteros = [FilteringTextInputFormatter.digitsOnly];

    return Form(
      key: _formKey,
      // Muestra los errores a medida que el usuario corrige cada campo.
      autovalidateMode: AutovalidateMode.onUserInteraction,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextFormField(
            controller: _nombre,
            decoration: const InputDecoration(
              labelText: 'Nombre del producto',
              prefixIcon: Icon(Icons.label_outline),
            ),
            textCapitalization: TextCapitalization.sentences,
            maxLength: 60,
            textInputAction: TextInputAction.next,
            validator: validarNombreProducto,
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: _categoria,
            decoration: const InputDecoration(
              labelText: 'Categoría',
              prefixIcon: Icon(Icons.category_outlined),
            ),
            items: [
              for (final categoria in categoriasProducto)
                DropdownMenuItem(value: categoria, child: Text(categoria)),
            ],
            onChanged: (valor) => setState(() => _categoria = valor),
            validator: validarCategoria,
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: TextFormField(
                  controller: _precio,
                  decoration: const InputDecoration(
                    labelText: 'Precio de venta',
                    prefixText: 'S/ ',
                  ),
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: soloImporte,
                  textInputAction: TextInputAction.next,
                  validator: validarPrecioVenta,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: _costo,
                  decoration: const InputDecoration(
                    labelText: 'Costo unitario',
                    prefixText: 'S/ ',
                  ),
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: soloImporte,
                  textInputAction: TextInputAction.next,
                  validator: validarCostoUnitario,
                ),
              ),
            ],
          ),
          _AvisoMargen(precio: _precio, costo: _costo),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: TextFormField(
                  controller: _stock,
                  decoration: const InputDecoration(
                    labelText: 'Stock disponible',
                    suffixText: 'u.',
                  ),
                  keyboardType: TextInputType.number,
                  inputFormatters: soloEnteros,
                  textInputAction: TextInputAction.next,
                  validator: (v) =>
                      validarEnteroNoNegativo(v, nombreCampo: 'el stock'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: _stockMinimo,
                  decoration: const InputDecoration(
                    labelText: 'Stock mínimo',
                    suffixText: 'u.',
                    helperText: 'Alerta de stock bajo',
                  ),
                  keyboardType: TextInputType.number,
                  inputFormatters: soloEnteros,
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (_) => _enviar(),
                  validator: (v) =>
                      validarEnteroNoNegativo(v, nombreCampo: 'el stock mínimo'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: widget.guardando ? null : _enviar,
            icon: widget.guardando
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_outlined),
            label: Text(esNuevo ? 'Registrar producto' : 'Guardar cambios'),
          ),
        ],
      ),
    );
  }
}

/// Muestra el margen por unidad mientras el usuario escribe precio y costo.
/// Avisa (sin bloquear) si el costo es mayor que el precio.
class _AvisoMargen extends StatelessWidget {
  const _AvisoMargen({required this.precio, required this.costo});

  final TextEditingController precio;
  final TextEditingController costo;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;

    // ListenableBuilder se redibuja cada vez que cambia alguno de los dos.
    return ListenableBuilder(
      listenable: Listenable.merge([precio, costo]),
      builder: (context, _) {
        final p = textoACentimos(precio.text);
        final c = textoACentimos(costo.text);
        if (p == null || c == null || p == 0) return const SizedBox.shrink();

        final margen = p - c;
        final porcentaje = margen * 100 / p;
        final negativo = margen < 0;

        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Row(
            children: [
              Icon(
                negativo ? Icons.warning_amber : Icons.trending_up,
                size: 18,
                color: negativo ? colores.error : colores.primary,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  negativo
                      ? 'El costo es mayor que el precio: se vendería con pérdida'
                      : 'Margen por unidad: ${formatearSoles(margen)} '
                          '(${formatearPorcentaje(porcentaje)})',
                  style: TextStyle(
                    color: negativo ? colores.error : colores.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
