/// DATOS FICTICIOS DE DEMOSTRACIÓN — no son ventas reales.
///
/// Son la ÚNICA fuente de datos demo del proyecto:
///   • El modo DEMO los carga en memoria al abrir la app.
///   • tool/exportar_datos_demo.dart los convierte a JSON y
///     scripts/firestore_admin.py los sube a Firestore.
///
/// Las fechas se calculan RELATIVAS al día de hoy ("hace 3 días"), para
/// que los gráficos de los últimos días siempre tengan información.
///
/// Todos los registros llevan esDemo = true y un id fijo (demo_p01,
/// demo_v001...). Con ids fijos, volver a cargarlos SOBRESCRIBE los mismos
/// documentos en vez de crear duplicados.
library;

import 'package:smartventas/models/detalle_venta.dart';
import 'package:smartventas/models/producto.dart';
import 'package:smartventas/models/venta.dart';

/// Precio que tenía el Cable USB-C antes de subir (S/ 17.90).
/// Las ventas de hace más de 15 días se hicieron con ese precio: sirve para
/// comprobar que el historial NO cambia cuando cambia el precio actual.
const int precioAnteriorCableUsbC = 1790;
const int diasDesdeCambioDePrecio = 15;

/// 12 productos de una tienda de accesorios tecnológicos.
/// El stock indicado es el que queda DESPUÉS de las ventas demo.
List<Producto> crearProductosDemo(DateTime hoy) {
  final fechaAlta = DateTime(hoy.year, hoy.month, hoy.day - 45, 9);

  Producto p(String id, String nombre, String categoria, int precio,
      int costo, int stock, int minimo) {
    return Producto(
      id: id,
      nombre: nombre,
      categoria: categoria,
      precioCentimos: precio,
      costoCentimos: costo,
      stock: stock,
      stockMinimo: minimo,
      fechaCreacion: fechaAlta,
      tieneVentas: true, // todos aparecen en alguna venta demo
      esDemo: true,
    );
  }

  return [
    p('demo_p01', 'Mouse inalámbrico', 'Periféricos', 4990, 3000, 25, 5),
    p('demo_p02', 'Teclado USB', 'Periféricos', 5990, 3600, 18, 5),
    p('demo_p03', 'Audífonos con micrófono', 'Audio', 8990, 5500, 12, 4),
    p('demo_p04', 'Cable USB-C 1 m', 'Cables', 1990, 850, 60, 15),
    p('demo_p05', 'Cargador rápido 20 W', 'Energía', 6990, 4200, 20, 5),
    p('demo_p06', 'Memoria USB 64 GB', 'Almacenamiento', 3490, 2100, 30, 8),
    p('demo_p07', 'Soporte para laptop', 'Accesorios', 7990, 4500, 8, 3),
    // Stock bajo a propósito (4 ≤ 5) para que aparezca la alerta.
    p('demo_p08', 'Adaptador HDMI a USB-C', 'Cables', 5490, 3000, 4, 5),
    p('demo_p09', 'Mouse pad gamer', 'Accesorios', 2990, 1400, 35, 10),
    p('demo_p10', 'Parlante Bluetooth', 'Audio', 12990, 8000, 6, 3),
    // Stock bajo a propósito (3 ≤ 4).
    p('demo_p11', 'Power bank 10 000 mAh', 'Energía', 9990, 6000, 3, 4),
    p('demo_p12', 'Hub USB 4 puertos', 'Accesorios', 4490, 2500, 14, 4),
  ];
}

/// Definición compacta de cada venta demo:
/// (días atrás, hora, minuto, {producto: cantidad}, ¿anulada?)
const List<(int, int, int, Map<String, int>, bool)> _ventasDefinidas = [
  (29, 10, 15, {'demo_p01': 1, 'demo_p04': 2}, false),
  (29, 17, 40, {'demo_p06': 1}, false),
  (28, 11, 5, {'demo_p03': 1}, false),
  (27, 16, 30, {'demo_p04': 3, 'demo_p05': 1}, false),
  (26, 12, 10, {'demo_p09': 2}, false),
  (25, 18, 45, {'demo_p02': 1, 'demo_p01': 1}, false),
  (24, 10, 0, {'demo_p10': 1}, false),
  (23, 15, 20, {'demo_p04': 1, 'demo_p06': 2}, false),
  (22, 13, 35, {'demo_p07': 1}, false),
  (21, 19, 5, {'demo_p05': 2}, false),
  (20, 11, 50, {'demo_p01': 2, 'demo_p09': 1}, false),
  (19, 16, 10, {'demo_p08': 1}, true), // ← venta ANULADA de ejemplo
  (18, 10, 30, {'demo_p03': 1, 'demo_p04': 1}, false),
  (17, 14, 0, {'demo_p12': 1}, false),
  (16, 17, 25, {'demo_p06': 1, 'demo_p04': 2}, false),
  (15, 12, 40, {'demo_p11': 1}, false),
  (14, 10, 5, {'demo_p01': 1}, false),
  (14, 18, 20, {'demo_p02': 1, 'demo_p09': 1}, false),
  (13, 11, 15, {'demo_p04': 4}, false),
  (12, 15, 45, {'demo_p05': 1, 'demo_p04': 1}, false),
  (11, 13, 10, {'demo_p10': 1, 'demo_p06': 1}, false),
  (10, 17, 30, {'demo_p03': 2}, false),
  (9, 10, 50, {'demo_p07': 1, 'demo_p12': 1}, false),
  (9, 19, 0, {'demo_p01': 1, 'demo_p04': 1}, false),
  (8, 12, 25, {'demo_p08': 1}, false),
  (7, 16, 40, {'demo_p06': 2}, false),
  (6, 11, 5, {'demo_p02': 1}, false),
  (6, 18, 15, {'demo_p09': 2, 'demo_p04': 2}, false),
  (5, 14, 30, {'demo_p05': 1}, false),
  (4, 10, 20, {'demo_p11': 1, 'demo_p04': 1}, false),
  (4, 17, 50, {'demo_p01': 2}, false),
  (3, 12, 0, {'demo_p03': 1, 'demo_p09': 1}, false),
  (3, 19, 30, {'demo_p12': 2}, false),
  (2, 11, 40, {'demo_p06': 1, 'demo_p04': 3}, false),
  (2, 16, 10, {'demo_p10': 1}, false),
  (1, 10, 35, {'demo_p02': 1, 'demo_p01': 1}, false),
  (1, 18, 5, {'demo_p07': 1}, false),
  (1, 20, 0, {'demo_p05': 1, 'demo_p04': 2}, false),
  (0, 10, 15, {'demo_p08': 1, 'demo_p04': 1}, false),
  (0, 11, 30, {'demo_p01': 1, 'demo_p09': 1}, false),
];

/// 40 ventas ficticias de los últimos 30 días (una de ellas anulada).
List<Venta> crearVentasDemo(DateTime hoy, List<Producto> productos) {
  final porId = {for (final p in productos) p.id: p};
  final ventas = <Venta>[];

  for (var i = 0; i < _ventasDefinidas.length; i++) {
    final (diasAtras, hora, minuto, lineas, anulada) = _ventasDefinidas[i];

    var fecha = DateTime(hoy.year, hoy.month, hoy.day - diasAtras, hora, minuto);
    // Una venta de "hoy" no puede quedar en el futuro: si la app se abre
    // a las 9:00, la venta de las 10:15 se mueve a unos minutos antes.
    if (fecha.isAfter(hoy)) {
      fecha = hoy.subtract(Duration(minutes: 5 * (_ventasDefinidas.length - i)));
    }

    final detalles = lineas.entries.map((linea) {
      final producto = porId[linea.key]!;
      final detalle = DetalleVenta.desdeProducto(producto, linea.value);
      final usaPrecioAnterior = producto.id == 'demo_p04' &&
          diasAtras > diasDesdeCambioDePrecio;
      if (!usaPrecioAnterior) return detalle;
      return DetalleVenta(
        productoId: detalle.productoId,
        nombreProducto: detalle.nombreProducto,
        categoria: detalle.categoria,
        precioUnitarioCentimos: precioAnteriorCableUsbC,
        costoUnitarioCentimos: detalle.costoUnitarioCentimos,
        cantidad: detalle.cantidad,
      );
    }).toList();

    final numero = i + 1;
    ventas.add(Venta(
      id: 'demo_v${numero.toString().padLeft(3, '0')}',
      numero: numero,
      fecha: fecha,
      detalles: detalles,
      estado: anulada ? EstadoVenta.anulada : EstadoVenta.confirmada,
      vendedorUid: 'demo',
      esDemo: true,
      fechaAnulacion: anulada ? fecha.add(const Duration(hours: 1)) : null,
    ));
  }
  return ventas;
}
