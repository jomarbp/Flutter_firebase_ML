/// Estadística descriptiva de las ventas (Módulo F).
///
/// QUÉ CONJUNTO ANALIZA CADA ESTADÍSTICO
///   • X = importe total de cada venta CONFIRMADA, en soles (numérico).
///         → media, mediana, varianzas, desviaciones, mínimo y máximo.
///   • U = unidades de cada venta confirmada (numérico discreto).
///         → promedio de unidades por venta, mínimo y máximo.
///   • P = producto de cada unidad vendida (CATEGÓRICO).
///         → solo frecuencias y porcentajes. ¡No tiene media ni varianza!
///   • C = categoría de cada línea vendida (CATEGÓRICO, ponderado por ingresos).
///         → porcentaje de los ingresos.
/// Nunca se mezclan importes (soles) con cantidades (unidades).
///
/// FÓRMULAS (n = cantidad de datos, x̄ = media)
///   media                  x̄  = Σxᵢ / n                     (n ≥ 1)
///   mediana                valor central de los datos ordenados; si n es
///                          par, el promedio de los dos centrales (n ≥ 1)
///   varianza poblacional   σ² = Σ(xᵢ − x̄)² / n              (n ≥ 1)
///   varianza muestral      s² = Σ(xᵢ − x̄)² / (n − 1)        (n ≥ 2)
///   desviación estándar    σ = √σ²   y   s = √s²
///   porcentaje             frecuencia / total × 100
///
/// EJEMPLO COMPROBABLE con X = [20, 30, 50]:
///   media = 100 / 3 = 33.33          mediana = 30
///   desvíos² = 177.78 + 11.11 + 277.78 = 466.67
///   σ² = 466.67 / 3 = 155.56  → σ = 12.47
///   s² = 466.67 / 2 = 233.33  → s = 15.28
///
/// Todas las funciones devuelven null cuando no hay datos suficientes.
library;

import 'dart:math' as math;

import 'package:smartventas/models/venta.dart';
import 'package:smartventas/utils/calculos_reportes.dart';

// ─────────────────────────── Funciones básicas ───────────────────────────

double? media(List<num> datos) {
  if (datos.isEmpty) return null;
  return datos.fold<double>(0, (s, x) => s + x) / datos.length;
}

double? mediana(List<num> datos) {
  if (datos.isEmpty) return null;
  final ordenados = [...datos]..sort();
  final mitad = ordenados.length ~/ 2;
  if (ordenados.length.isOdd) return ordenados[mitad].toDouble();
  return (ordenados[mitad - 1] + ordenados[mitad]) / 2;
}

/// Suma de los desvíos al cuadrado: Σ(xᵢ − x̄)².
double _sumaDesviosCuadrados(List<num> datos) {
  final m = media(datos)!;
  return datos.fold<double>(0, (s, x) => s + (x - m) * (x - m));
}

/// σ²: se usa cuando los datos son TODA la población (todas las ventas).
double? varianzaPoblacional(List<num> datos) {
  if (datos.isEmpty) return null;
  return _sumaDesviosCuadrados(datos) / datos.length;
}

/// s²: se usa cuando los datos son una MUESTRA (por ejemplo, un mes como
/// muestra del comportamiento general). Necesita al menos 2 datos.
double? varianzaMuestral(List<num> datos) {
  if (datos.length < 2) return null;
  return _sumaDesviosCuadrados(datos) / (datos.length - 1);
}

double? desviacionPoblacional(List<num> datos) {
  final v = varianzaPoblacional(datos);
  return v == null ? null : math.sqrt(v);
}

double? desviacionMuestral(List<num> datos) {
  final v = varianzaMuestral(datos);
  return v == null ? null : math.sqrt(v);
}

num? minimo(List<num> datos) {
  if (datos.isEmpty) return null;
  // Se usa un bucle (no reduce) para aceptar List<int> y List<double>.
  num menor = datos.first;
  for (final x in datos) {
    if (x < menor) menor = x;
  }
  return menor;
}

num? maximo(List<num> datos) {
  if (datos.isEmpty) return null;
  num mayor = datos.first;
  for (final x in datos) {
    if (x > mayor) mayor = x;
  }
  return mayor;
}

/// Cuántas veces aparece cada valor, de mayor a menor frecuencia.
Map<T, int> frecuencias<T>(Iterable<T> datos) {
  final conteo = <T, int>{};
  for (final d in datos) {
    conteo[d] = (conteo[d] ?? 0) + 1;
  }
  final ordenado = conteo.entries.toList()
    ..sort((a, b) => b.value.compareTo(a.value));
  return {for (final e in ordenado) e.key: e.value};
}

/// Porcentaje de cada clave respecto del total. Vacío si el total es 0.
Map<T, double> porcentajes<T>(Map<T, num> valores) {
  final total = valores.values.fold<num>(0, (s, v) => s + v);
  if (total == 0) return {};
  return {for (final e in valores.entries) e.key: e.value * 100 / total};
}

// ─────────────────────────── Resumen de un conjunto ───────────────────────────

// Alias de las funciones para usarlos dentro de ResumenEstadistico.
const _media = media;
const _mediana = mediana;
const _varPob = varianzaPoblacional;
const _varMuestral = varianzaMuestral;
const _desvPob = desviacionPoblacional;
const _desvMuestral = desviacionMuestral;
const _min = minimo;
const _max = maximo;

/// Todos los estadísticos de un conjunto numérico de una vez.
class ResumenEstadistico {
  const ResumenEstadistico._({
    required this.n,
    this.media,
    this.mediana,
    this.varianzaPoblacional,
    this.varianzaMuestral,
    this.desviacionPoblacional,
    this.desviacionMuestral,
    this.minimo,
    this.maximo,
  });

  // Dentro de la clase, "media" sería el CAMPO; por eso se usan las
  // funciones a través de los alias privados de abajo.
  factory ResumenEstadistico.de(List<num> datos) => ResumenEstadistico._(
        n: datos.length,
        media: _media(datos),
        mediana: _mediana(datos),
        varianzaPoblacional: _varPob(datos),
        varianzaMuestral: _varMuestral(datos),
        desviacionPoblacional: _desvPob(datos),
        desviacionMuestral: _desvMuestral(datos),
        minimo: _min(datos),
        maximo: _max(datos),
      );

  final int n;
  final double? media;
  final double? mediana;
  final double? varianzaPoblacional;
  final double? varianzaMuestral;
  final double? desviacionPoblacional;
  final double? desviacionMuestral;
  final num? minimo;
  final num? maximo;
}

// ─────────────────────────── Conjuntos de datos de SmartVentas ───────────────────────────

/// X: importe de cada venta confirmada EN SOLES (4990 céntimos → 49.9).
/// Se convierte a double solo aquí, para la estadística; el redondeo se
/// hace al MOSTRAR el resultado (2 decimales).
List<double> importesDeVentas(Iterable<Venta> ventas) =>
    ventasConfirmadas(ventas).map((v) => v.totalCentimos / 100).toList();

/// U: unidades de cada venta confirmada.
List<int> unidadesPorVenta(Iterable<Venta> ventas) =>
    ventasConfirmadas(ventas).map((v) => v.unidadesTotales).toList();

/// Promedio de unidades por venta (media de U).
double? promedioUnidadesPorVenta(Iterable<Venta> ventas) =>
    media(unidadesPorVenta(ventas));

/// P: frecuencia de cada producto = unidades vendidas de ese producto.
/// (Cada unidad vendida es una observación del producto.)
Map<String, int> frecuenciaProductos(Iterable<Venta> ventas) {
  final conteo = <String, int>{};
  for (final v in ventasConfirmadas(ventas)) {
    for (final d in v.detalles) {
      conteo[d.nombreProducto] = (conteo[d.nombreProducto] ?? 0) + d.cantidad;
    }
  }
  final ordenado = conteo.entries.toList()
    ..sort((a, b) => b.value.compareTo(a.value));
  return {for (final e in ordenado) e.key: e.value};
}
