import 'package:flutter/material.dart';

import 'package:smartventas/models/venta.dart';
import 'package:smartventas/screens/comprobante_screen.dart';
import 'package:smartventas/services/excepciones.dart';
import 'package:smartventas/services/venta_service.dart';
import 'package:smartventas/utils/formato.dart';

/// Detalle de una venta del historial: productos, cantidades, precios del
/// momento, total, costo estimado y margen. El administrador puede anularla.
class DetalleVentaScreen extends StatefulWidget {
  const DetalleVentaScreen({
    super.key,
    required this.venta,
    required this.ventaService,
    this.puedeAnular = false,
  });

  final Venta venta;
  final VentaService ventaService;
  final bool puedeAnular;

  @override
  State<DetalleVentaScreen> createState() => _DetalleVentaScreenState();
}

class _DetalleVentaScreenState extends State<DetalleVentaScreen> {
  late Venta _venta = widget.venta;
  bool _anulando = false;

  Future<void> _anular() async {
    final confirmado = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.block),
        title: Text('Anular ${_venta.codigo}'),
        content: Text(
          'La venta quedará como ANULADA y se devolverán '
          '${_venta.unidadesTotales} unidades al stock.\n\n'
          'No se puede deshacer y la venta no se borra: queda en el '
          'historial, pero deja de contar en los reportes.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
              foregroundColor: Theme.of(context).colorScheme.onError,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Anular venta'),
          ),
        ],
      ),
    );
    if (confirmado != true || !mounted) return;

    setState(() => _anulando = true);
    try {
      final anulada = await widget.ventaService.anularVenta(_venta.id);
      if (!mounted) return;
      setState(() => _venta = anulada);
      _mensaje('Venta anulada y stock devuelto');
    } on SmartVentasException catch (error) {
      _mensaje(error.mensaje, esError: true);
    } catch (error) {
      _mensaje('No se pudo anular la venta: $error', esError: true);
    } finally {
      if (mounted) setState(() => _anulando = false);
    }
  }

  void _mensaje(String texto, {bool esError = false}) {
    if (!mounted) return;
    final colores = Theme.of(context).colorScheme;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(texto),
      backgroundColor: esError ? colores.error : null,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final textos = Theme.of(context).textTheme;
    final venta = _venta;
    final margen = venta.margenBrutoCentimos;

    return Scaffold(
      appBar: AppBar(title: Text('Venta ${venta.codigo}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TarjetaComprobante(venta: venta),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Para el negocio', style: textos.titleSmall),
                  const SizedBox(height: 8),
                  _Fila('Costo estimado', formatearSoles(venta.costoTotalCentimos)),
                  _Fila(
                    'Margen bruto estimado',
                    '${formatearSoles(margen)}'
                        '${venta.totalCentimos == 0 ? '' : ' (${formatearPorcentaje(margen * 100 / venta.totalCentimos)})'}',
                  ),
                  if (!venta.estaConfirmada)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'Venta anulada: no cuenta en los reportes.',
                        style: textos.bodySmall,
                      ),
                    ),
                ],
              ),
            ),
          ),
          if (widget.puedeAnular && venta.estaConfirmada) ...[
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: _anulando ? null : _anular,
              icon: _anulando
                  ? const SizedBox.square(
                      dimension: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.block),
              label: Text(_anulando ? 'Anulando…' : 'Anular venta'),
            ),
          ],
        ],
      ),
    );
  }
}

class _Fila extends StatelessWidget {
  const _Fila(this.etiqueta, this.valor);

  final String etiqueta;
  final String valor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(child: Text(etiqueta)),
          Text(valor, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
