import 'package:flutter/material.dart';

import 'package:smartventas/models/producto.dart';
import 'package:smartventas/services/excepciones.dart';
import 'package:smartventas/services/producto_service.dart';
import 'package:smartventas/widgets/formulario_producto.dart';

/// Pantalla para registrar un producto nuevo o editar uno existente.
///
/// Al guardar con éxito, cierra la pantalla y devuelve un mensaje
/// (String) que la lista de productos muestra en un SnackBar.
class ProductoFormScreen extends StatefulWidget {
  const ProductoFormScreen({
    super.key,
    required this.productoService,
    this.producto,
  });

  final ProductoService productoService;

  /// null = registrar; con valor = editar.
  final Producto? producto;

  @override
  State<ProductoFormScreen> createState() => _ProductoFormScreenState();
}

class _ProductoFormScreenState extends State<ProductoFormScreen> {
  bool _guardando = false;

  Future<void> _guardar(Producto borrador) async {
    setState(() => _guardando = true);
    try {
      final String mensaje;
      if (widget.producto == null) {
        final creado = await widget.productoService.crearProducto(borrador);
        mensaje = 'Producto "${creado.nombre}" registrado';
      } else {
        await widget.productoService.actualizarProducto(borrador);
        mensaje = 'Cambios guardados en "${borrador.nombre}"';
      }
      // Después de un "await" la pantalla podría haberse cerrado:
      // "mounted" indica si todavía está visible.
      if (!mounted) return;
      Navigator.of(context).pop(mensaje);
    } on SmartVentasException catch (error) {
      _mostrarError(error.mensaje);
    } catch (error) {
      _mostrarError('No se pudo guardar el producto. Intenta nuevamente.');
    } finally {
      if (mounted) setState(() => _guardando = false);
    }
  }

  void _mostrarError(String mensaje) {
    if (!mounted) return;
    final colores = Theme.of(context).colorScheme;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensaje),
        backgroundColor: colores.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final producto = widget.producto;

    // PopScope impide salir con el botón "Atrás" mientras se guarda.
    return PopScope(
      canPop: !_guardando,
      child: Scaffold(
        appBar: AppBar(
          title: Text(producto == null ? 'Nuevo producto' : 'Editar producto'),
        ),
        body: Column(
          children: [
            if (producto != null && producto.tieneVentas)
              const _AvisoHistorial(),
            Expanded(
              child: FormularioProducto(
                productoInicial: producto,
                guardando: _guardando,
                alGuardar: _guardar,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AvisoHistorial extends StatelessWidget {
  const _AvisoHistorial();

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      color: colores.secondaryContainer,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Icon(Icons.history, color: colores.onSecondaryContainer),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Este producto tiene ventas. Cambiar el precio no modifica '
              'las ventas ya registradas.',
              style: TextStyle(color: colores.onSecondaryContainer),
            ),
          ),
        ],
      ),
    );
  }
}
