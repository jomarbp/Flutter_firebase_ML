import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:smartventas/models/producto.dart';
import 'package:smartventas/services/excepciones.dart';
import 'package:smartventas/utils/formato.dart';
import 'package:smartventas/utils/validaciones.dart';

/// Resultado de pedir que se elimine un producto.
enum ResultadoEliminacion {
  /// No tenía ventas: se borró definitivamente.
  eliminado,

  /// Tenía ventas: se conservó como inactivo para no romper el historial.
  desactivado,
}

/// CONTRATO (interfaz) del servicio de productos.
///
/// Una clase `abstract` solo dice QUÉ se puede hacer, no CÓMO.
/// Hay dos implementaciones:
///   • MemoriaProductoService   → datos ficticios en memoria (modo DEMO)
///   • FirestoreProductoService → Cloud Firestore (más abajo)
/// Las pantallas solo conocen esta interfaz, así que funcionan con
/// cualquiera de las dos sin cambiar su código.
abstract class ProductoService {
  /// Lista de TODOS los productos (activos e inactivos) que se actualiza
  /// sola cada vez que hay un cambio.
  Stream<List<Producto>> observarProductos();

  /// Lista de productos en este momento (una sola vez).
  Future<List<Producto>> obtenerProductos();

  /// Un producto por su id, o null si no existe.
  Future<Producto?> obtenerProducto(String id);

  /// Registra un producto nuevo. El servicio asigna el id y la fecha de
  /// creación y devuelve el producto guardado.
  Future<Producto> crearProducto(Producto borrador);

  /// Guarda los cambios de un producto existente.
  Future<void> actualizarProducto(Producto producto);

  /// Elimina el producto si no tiene ventas; si las tiene, lo desactiva.
  Future<ResultadoEliminacion> eliminarProducto(String id);

  /// Vuelve a activar un producto desactivado.
  Future<void> reactivarProducto(String id);
}

/// Productos guardados en Cloud Firestore: colección "productos".
///
/// Aplica las mismas reglas que la versión en memoria. Las reglas de
/// seguridad (firestore.rules) vuelven a validar en el SERVIDOR.
class FirestoreProductoService implements ProductoService {
  FirestoreProductoService({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _coleccion =>
      _db.collection('productos');

  Producto _desdeDocumento(DocumentSnapshot<Map<String, dynamic>> documento) =>
      Producto.fromMap(documento.id, documento.data()!);

  void _validar(Producto producto) {
    final errores = validarProducto(producto);
    if (errores.isNotEmpty) throw DatosInvalidosException(errores);
  }

  /// Busca otro producto con el mismo nombre normalizado.
  Future<void> _verificarNombreUnico(String nombre, {String? exceptoId}) async {
    final consulta = await _coleccion
        .where('nombreNormalizado', isEqualTo: normalizarTexto(nombre.trim()))
        .limit(2)
        .get();
    final repetido = consulta.docs.any((d) => d.id != exceptoId);
    if (repetido) throw ProductoDuplicadoException(nombre.trim());
  }

  @override
  Stream<List<Producto>> observarProductos() {
    // snapshots() emite la lista actual y luego cada cambio, igual que
    // la versión en memoria.
    return _coleccion
        .snapshots()
        .map((consulta) => consulta.docs.map(_desdeDocumento).toList());
  }

  @override
  Future<List<Producto>> obtenerProductos() async {
    final consulta = await _coleccion.get();
    return consulta.docs.map(_desdeDocumento).toList();
  }

  @override
  Future<Producto?> obtenerProducto(String id) async {
    final documento = await _coleccion.doc(id).get();
    return documento.exists ? _desdeDocumento(documento) : null;
  }

  @override
  Future<Producto> crearProducto(Producto borrador) async {
    // doc() sin argumentos genera un id nuevo en el dispositivo.
    final referencia = _coleccion.doc();
    final producto = borrador.copyWith(
      id: referencia.id,
      nombre: borrador.nombre.trim(),
      fechaCreacion: DateTime.now(),
      activo: true,
      tieneVentas: false,
      esDemo: false,
    );
    _validar(producto);
    await _verificarNombreUnico(producto.nombre);

    await referencia.set({
      ...producto.toMap(),
      'fechaActualizacion': FieldValue.serverTimestamp(),
    });
    return producto;
  }

  @override
  Future<void> actualizarProducto(Producto producto) async {
    final actual = await obtenerProducto(producto.id);
    if (actual == null) throw ProductoNoEncontradoException(producto.id);

    final actualizado = producto.copyWith(
      nombre: producto.nombre.trim(),
      fechaCreacion: actual.fechaCreacion,
      tieneVentas: actual.tieneVentas,
      esDemo: actual.esDemo,
    );
    _validar(actualizado);
    await _verificarNombreUnico(actualizado.nombre, exceptoId: actualizado.id);

    await _coleccion.doc(producto.id).update({
      ...actualizado.toMap(),
      'fechaActualizacion': FieldValue.serverTimestamp(),
    });
  }

  @override
  Future<ResultadoEliminacion> eliminarProducto(String id) {
    // Transacción: si justo se registra una venta de este producto,
    // se vuelve a leer "tieneVentas" antes de decidir.
    return _db.runTransaction((transaccion) async {
      final referencia = _coleccion.doc(id);
      final documento = await transaccion.get(referencia);
      if (!documento.exists) throw ProductoNoEncontradoException(id);

      if (documento.data()!['tieneVentas'] == true) {
        transaccion.update(referencia, {
          'activo': false,
          'fechaActualizacion': FieldValue.serverTimestamp(),
        });
        return ResultadoEliminacion.desactivado;
      }
      transaccion.delete(referencia);
      return ResultadoEliminacion.eliminado;
    });
  }

  @override
  Future<void> reactivarProducto(String id) async {
    final referencia = _coleccion.doc(id);
    if (!(await referencia.get()).exists) throw ProductoNoEncontradoException(id);
    await referencia.update({
      'activo': true,
      'fechaActualizacion': FieldValue.serverTimestamp(),
    });
  }
}
