import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'package:smartventas/config.dart';
import 'package:smartventas/screens/inicio_screen.dart';
import 'package:smartventas/screens/login_screen.dart';
import 'package:smartventas/services/auth_service.dart';
import 'package:smartventas/services/servicios.dart';
import 'package:smartventas/widgets/etiqueta_origen_datos.dart';

/// Widget raíz: configura el tema Material 3 y la pantalla inicial.
class SmartVentasApp extends StatelessWidget {
  const SmartVentasApp({super.key, required this.servicios});

  /// Servicios de datos (demo o Firebase) que usarán las pantallas.
  final Servicios servicios;

  /// Color base del que Material 3 genera toda la paleta.
  static const Color colorSemilla = Color(0xFF1565C0);

  @override
  Widget build(BuildContext context) {
    // OrigenDatos va por ENCIMA de MaterialApp para que todas las
    // pantallas (incluidas las que se abren con Navigator) lo vean.
    return OrigenDatos(
      esFirebase: servicios.esFirebase,
      child: MaterialApp(
        title: AppConfig.nombreApp,
        debugShowCheckedModeBanner: false,
        theme: _crearTema(Brightness.light),
        darkTheme: _crearTema(Brightness.dark),
        themeMode: ThemeMode.system,
        // Textos de Material (calendario, botones) en español de Perú.
        locale: const Locale('es', 'PE'),
        supportedLocales: const [Locale('es', 'PE'), Locale('es')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: _PuertaDeSesion(servicios: servicios),
      ),
    );
  }

  /// Crea el tema claro u oscuro a partir del mismo color semilla.
  ThemeData _crearTema(Brightness brillo) {
    final esquema = ColorScheme.fromSeed(
      seedColor: colorSemilla,
      brightness: brillo,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: esquema,
      appBarTheme: AppBarTheme(
        centerTitle: false,
        backgroundColor: esquema.surface,
        foregroundColor: esquema.onSurface,
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: esquema.surfaceContainerLow,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
      ),
      snackBarTheme: const SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

/// Decide qué mostrar según la sesión:
///   • esperando → indicador de carga
///   • sin sesión → LoginScreen
///   • con sesión → InicioScreen
class _PuertaDeSesion extends StatefulWidget {
  const _PuertaDeSesion({required this.servicios});

  final Servicios servicios;

  @override
  State<_PuertaDeSesion> createState() => _PuertaDeSesionState();
}

class _PuertaDeSesionState extends State<_PuertaDeSesion> {
  // Se crea una sola vez (no en build) para no repetir la suscripción.
  late final Stream<Usuario?> _sesion = widget.servicios.auth.observarSesion();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Usuario?>(
      stream: _sesion,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        final usuario = snapshot.data;
        if (usuario == null) {
          return LoginScreen(authService: widget.servicios.auth);
        }
        // La "key" con el uid hace que, si entra otro usuario, todas las
        // pantallas se creen de nuevo (carrito vacío, etc.).
        return InicioScreen(
          key: ValueKey(usuario.uid),
          servicios: widget.servicios,
          usuario: usuario,
        );
      },
    );
  }
}
