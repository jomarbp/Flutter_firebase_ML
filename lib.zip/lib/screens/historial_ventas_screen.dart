import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:smartventas/models/venta.dart';
import 'package:smartventas/screens/detalle_venta_screen.dart';
import 'package:smartventas/services/venta_service.dart';
import 'package:smartventas/utils/calculos_reportes.dart';
import 'package:smartventas/utils/formato.dart';
import 'package:smartventas/widgets/estado_error.dart';
import 'package:smartventas/widgets/estado_vacio.dart';
import 'package:smartventas/widgets/etiqueta_origen_datos.dart';

/// Historial de ventas: lista, búsqueda por número y filtro por fechas.
///
/// Las ventas confirmadas NO se editan desde aquí. El administrador puede
/// anular una venta desde su detalle (el stock se devuelve una sola vez).
class HistorialVentasScreen extends StatefulWidget {
  const HistorialVentasScreen({
    super.key,
    required this.ventaService,
    this.puedeAnular = false,
  });

  final VentaService ventaService;

  /// true solo para el administrador.
  final bool puedeAnular;

  @override
  State<HistorialVentasScreen> createState() => _HistorialVentasScreenState();
}

class _HistorialVentasScreenState extends State<HistorialVentasScreen> {
  late Stream<List<Venta>> _ventas;
  final _busqueda = TextEditingController();
  DateTimeRange? _rango;

  @override
  void initState() {
    super.initState();
    _suscribir();
  }

  void _suscribir() => _ventas = widget.ventaService.observarVentas();

  @override
  void dispose() {
    _busqueda.dispose();
    super.dispose();
  }

  Future<void> _elegirFechas() async {
    final hoy = DateTime.now();
    final rango = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: hoy,
      initialDateRange: _rango,
      helpText: 'Filtrar ventas por fecha',
      saveText: 'Aplicar',
    );
    if (rango != null) setState(() => _rango = rango);
  }

  void _limpiar() {
    _busqueda.clear();
    setState(() => _rango = null);
  }

  void _abrirDetalle(Venta venta) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => DetalleVentaScreen(
        venta: venta,
        ventaService: widget.ventaService,
        puedeAnular: widget.puedeAnular,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final hayFiltros = _busqueda.text.isNotEmpty || _rango != null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Historial de ventas'),
        actions: const [EtiquetaOrigenDatos(), SizedBox(width: 12)],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _busqueda,
                    decoration: const InputDecoration(
                      hintText: 'N.º de venta (ej. 41)',
                      prefixIcon: Icon(Icons.search),
                      isDense: true,
                    ),
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9vV-]')),
                    ],
                    onChanged: (_) => setState(() {}),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(
                  tooltip: 'Filtrar por fechas',
                  onPressed: _elegirFechas,
                  icon: const Icon(Icons.date_range),
                ),
              ],
            ),
          ),
          if (hayFiltros)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  if (_rango != null)
                    Expanded(
                      child: Text(
                        'Del ${formatearFecha(_rango!.start)} '
                        'al ${formatearFecha(_rango!.end)}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    )
                  else
                    const Spacer(),
                  TextButton.icon(
                    onPressed: _limpiar,
                    icon: const Icon(Icons.filter_alt_off, size: 18),
                    label: const Text('Quitar filtros'),
                  ),
                ],
              ),
            ),
          Expanded(child: _construirLista()),
        ],
      ),
    );
  }

  Widget _construirLista() {
    return StreamBuilder<List<Venta>>(
      stream: _ventas,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return EstadoError(
            mensaje: 'No se pudo cargar el historial.\n${snapshot.error}',
            alReintentar: () => setState(_suscribir),
          );
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final todas = snapshot.data!;
        if (todas.isEmpty) {
          return const EstadoVacio(
            icono: Icons.receipt_long_outlined,
            titulo: 'No existen operaciones registradas',
            mensaje: 'Las ventas confirmadas aparecerán aquí.',
          );
        }

        final visibles = filtrarVentas(
          todas,
          texto: _busqueda.text,
          desde: _rango?.start,
          hasta: _rango?.end,
        );
        if (visibles.isEmpty) {
          return EstadoVacio(
            icono: Icons.search_off,
            titulo: 'Sin resultados',
            mensaje: 'Ninguna venta coincide con el número o las fechas.',
            accion: OutlinedButton(
              onPressed: _limpiar,
              child: const Text('Quitar filtros'),
            ),
          );
        }

        final resumen = ResumenVentas.de(visibles);
        final anuladas = visibles.length - resumen.numeroVentas;

        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
          itemCount: visibles.length + 1,
          itemBuilder: (context, indice) {
            if (indice == 0) {
              return Padding(
                padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
                child: Text(
                  '${visibles.length} ventas · '
                  '${formatearSoles(resumen.ingresosCentimos)} confirmadas'
                  '${anuladas > 0 ? ' · $anuladas anuladas' : ''}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              );
            }
            final venta = visibles[indice - 1];
            return _TarjetaVenta(venta: venta, alTocar: () => _abrirDetalle(venta));
          },
        );
      },
    );
  }
}

class _TarjetaVenta extends StatelessWidget {
  const _TarjetaVenta({required this.venta, required this.alTocar});

  final Venta venta;
  final VoidCallback alTocar;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;
    final anulada = !venta.estaConfirmada;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        onTap: alTocar,
        leading: CircleAvatar(
          backgroundColor:
              anulada ? colores.errorContainer : colores.primaryContainer,
          foregroundColor:
              anulada ? colores.onErrorContainer : colores.onPrimaryContainer,
          child: Icon(anulada ? Icons.block : Icons.receipt_outlined),
        ),
        title: Row(
          children: [
            Text(venta.codigo, style: textos.titleSmall),
            if (anulada) ...[
              const SizedBox(width: 8),
              Text('ANULADA',
                  style: textos.labelSmall?.copyWith(color: colores.error)),
            ],
            if (venta.esDemo) ...[
              const SizedBox(width: 8),
              Text('demo', style: textos.labelSmall),
            ],
          ],
        ),
        subtitle: Text(
          '${formatearFechaHora(venta.fecha)} · ${venta.unidadesTotales} u.',
        ),
        trailing: Text(
          formatearSoles(venta.totalCentimos),
          style: textos.titleSmall?.copyWith(
            fontWeight: FontWeight.bold,
            decoration: anulada ? TextDecoration.lineThrough : null,
            color: anulada ? colores.onSurfaceVariant : null,
          ),
        ),
      ),
    );
  }
}
