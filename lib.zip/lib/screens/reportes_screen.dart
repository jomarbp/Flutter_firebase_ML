import 'package:flutter/material.dart';

import 'package:smartventas/models/producto.dart';
import 'package:smartventas/models/venta.dart';
import 'package:smartventas/services/producto_service.dart';
import 'package:smartventas/services/venta_service.dart';
import 'package:smartventas/utils/calculos_reportes.dart';
import 'package:smartventas/utils/estadisticas.dart';
import 'package:smartventas/utils/formato.dart';
import 'package:smartventas/widgets/estado_error.dart';
import 'package:smartventas/widgets/etiqueta_origen_datos.dart';
import 'package:smartventas/widgets/grafico_barras.dart';
import 'package:smartventas/widgets/grafico_lineas.dart';

/// Reportes comerciales (Módulo E), gráficos (Módulo G) y estadística
/// (Módulo F), para el período elegido.
class ReportesScreen extends StatefulWidget {
  const ReportesScreen({
    super.key,
    required this.ventaService,
    required this.productoService,
  });

  final VentaService ventaService;
  final ProductoService productoService;

  @override
  State<ReportesScreen> createState() => _ReportesScreenState();
}

class _ReportesScreenState extends State<ReportesScreen> {
  late Stream<List<Venta>> _ventas;
  late Stream<List<Producto>> _productos;
  late DateTimeRange _rango = _ultimosDias(30);
  String _preset = '30 días';

  @override
  void initState() {
    super.initState();
    _suscribir();
  }

  void _suscribir() {
    _ventas = widget.ventaService.observarVentas();
    _productos = widget.productoService.observarProductos();
  }

  static DateTimeRange _ultimosDias(int dias) {
    final hoy = soloFecha(DateTime.now());
    return DateTimeRange(
      start: DateTime(hoy.year, hoy.month, hoy.day - dias + 1),
      end: hoy,
    );
  }

  void _elegirPreset(String nombre) {
    final hoy = soloFecha(DateTime.now());
    setState(() {
      _preset = nombre;
      _rango = switch (nombre) {
        '7 días' => _ultimosDias(7),
        'Este mes' => DateTimeRange(start: DateTime(hoy.year, hoy.month), end: hoy),
        _ => _ultimosDias(30),
      };
    });
  }

  Future<void> _elegirFechas() async {
    final rango = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      initialDateRange: _rango,
      helpText: 'Período del reporte',
      saveText: 'Aplicar',
    );
    if (rango != null) {
      setState(() {
        _rango = rango;
        _preset = '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Reportes'),
          actions: const [EtiquetaOrigenDatos(), SizedBox(width: 12)],
          bottom: const TabBar(tabs: [
            Tab(text: 'Resumen'),
            Tab(text: 'Productos'),
            Tab(text: 'Estadística'),
          ]),
        ),
        body: Column(
          children: [
            _barraPeriodo(),
            Expanded(
              child: StreamBuilder<List<Venta>>(
                stream: _ventas,
                builder: (context, ventas) => StreamBuilder<List<Producto>>(
                  stream: _productos,
                  builder: (context, productos) {
                    final error = ventas.error ?? productos.error;
                    if (error != null) {
                      return EstadoError(
                        mensaje: 'No se pudieron cargar los reportes.\n$error',
                        alReintentar: () => setState(_suscribir),
                      );
                    }
                    if (!ventas.hasData || !productos.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    final todas = ventas.data!;
                    final delPeriodo =
                        ventasEnRango(todas, desde: _rango.start, hasta: _rango.end);
                    return TabBarView(children: [
                      _TabResumen(todas: todas, delPeriodo: delPeriodo, rango: _rango),
                      _TabProductos(delPeriodo: delPeriodo, productos: productos.data!),
                      _TabEstadistica(delPeriodo: delPeriodo),
                    ]);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _barraPeriodo() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: Row(
        children: [
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  for (final nombre in ['7 días', '30 días', 'Este mes'])
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(nombre),
                        selected: _preset == nombre,
                        onSelected: (_) => _elegirPreset(nombre),
                      ),
                    ),
                ],
              ),
            ),
          ),
          TextButton.icon(
            onPressed: _elegirFechas,
            icon: const Icon(Icons.date_range, size: 18),
            label: Text('${formatearDiaMes(_rango.start)}–${formatearDiaMes(_rango.end)}'),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════ Pestaña RESUMEN ═══════════════════════════

class _TabResumen extends StatelessWidget {
  const _TabResumen({required this.todas, required this.delPeriodo, required this.rango});

  final List<Venta> todas;
  final List<Venta> delPeriodo;
  final DateTimeRange rango;

  @override
  Widget build(BuildContext context) {
    final resumen = ResumenVentas.de(delPeriodo);
    final comparacion = compararPeriodos(todas, desde: rango.start, hasta: rango.end);
    final porDiaActual = ingresosPorDia(todas, desde: rango.start, hasta: rango.end);
    final porDiaAnterior = ingresosPorDia(todas,
        desde: comparacion.desdeAnterior, hasta: comparacion.hastaAnterior);
    final dias = porDiaActual.length;
    final cadaEtiqueta = dias <= 10 ? 1 : (dias / 6).ceil();

    final listaActual = porDiaActual.entries.toList();
    final listaAnterior = porDiaAnterior.values.toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _Seccion(
          titulo: 'Resultado del período',
          child: Column(
            children: [
              _Fila('Ingresos por ventas', formatearSoles(resumen.ingresosCentimos),
                  destacado: true),
              _Fila('Costo estimado de lo vendido', formatearSoles(resumen.costoCentimos)),
              _Fila(
                'Margen bruto estimado',
                '${formatearSoles(resumen.margenBrutoCentimos)}'
                    '${resumen.margenPorcentaje == null ? '' : ' (${formatearPorcentaje(resumen.margenPorcentaje!)})'}',
                destacado: true,
              ),
              const Divider(),
              _Fila('Ventas confirmadas', '${resumen.numeroVentas}'),
              _Fila('Unidades vendidas', '${resumen.unidades}'),
              _Fila(
                'Ticket promedio',
                resumen.ticketPromedioCentimos == null
                    ? '—'
                    : formatearSoles(resumen.ticketPromedioCentimos!),
              ),
              const SizedBox(height: 8),
              const _Nota(
                'La GANANCIA NETA no se calcula: requiere restar alquiler, '
                'sueldos, impuestos y otros gastos que la app no registra. '
                'El costo es una estimación con el costo unitario guardado en '
                'cada venta.',
              ),
            ],
          ),
        ),
        _Seccion(
          titulo: 'Ingresos por día',
          child: GraficoLineas(
            datos: [
              for (final e in listaActual)
                DatoGrafico(formatearDiaMes(e.key), e.value / 100,
                    detalle: formatearFecha(e.key)),
            ],
            formatearValor: formatearSolesDecimal,
            formatearEje: formatearSolesCorto,
            etiquetaCada: cadaEtiqueta,
          ),
        ),
        _Seccion(
          titulo: 'Comparación con el período anterior',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Actual: ${formatearFecha(comparacion.desdeActual)} – '
                '${formatearFecha(comparacion.hastaActual)}\n'
                'Anterior: ${formatearFecha(comparacion.desdeAnterior)} – '
                '${formatearFecha(comparacion.hastaAnterior)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              _TablaComparacion(comparacion: comparacion),
              const SizedBox(height: 16),
              Text('Ingresos por día de cada período',
                  style: Theme.of(context).textTheme.labelLarge),
              const SizedBox(height: 8),
              GraficoBarras(
                nombresSeries: const ['Período actual', 'Período anterior'],
                datos: [
                  for (var i = 0; i < listaActual.length; i++)
                    DatoGrafico(
                      'D${i + 1}',
                      listaActual[i].value / 100,
                      valor2: i < listaAnterior.length ? listaAnterior[i] / 100 : 0,
                      detalle: 'Día ${i + 1} (${formatearDiaMes(listaActual[i].key)})',
                    ),
                ],
                formatearValor: formatearSolesDecimal,
                formatearEje: formatearSolesCorto,
                etiquetaCada: cadaEtiqueta,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _TablaComparacion extends StatelessWidget {
  const _TablaComparacion({required this.comparacion});

  final ComparacionPeriodos comparacion;

  @override
  Widget build(BuildContext context) {
    final a = comparacion.actual;
    final b = comparacion.anterior;
    final filas = [
      ('Ingresos', formatearSoles(a.ingresosCentimos),
          formatearSoles(b.ingresosCentimos), comparacion.variacionIngresos),
      ('Ventas', '${a.numeroVentas}', '${b.numeroVentas}', comparacion.variacionVentas),
      ('Unidades', '${a.unidades}', '${b.unidades}', comparacion.variacionUnidades),
      ('Margen bruto', formatearSoles(a.margenBrutoCentimos),
          formatearSoles(b.margenBrutoCentimos), comparacion.variacionMargen),
    ];
    final estiloCabecera = Theme.of(context).textTheme.labelMedium;

    return Table(
      columnWidths: const {
        0: FlexColumnWidth(1.3),
        1: FlexColumnWidth(1.4),
        2: FlexColumnWidth(1.4),
        3: FlexColumnWidth(1.1),
      },
      defaultVerticalAlignment: TableCellVerticalAlignment.middle,
      children: [
        TableRow(children: [
          Text('', style: estiloCabecera),
          Text('Actual', style: estiloCabecera),
          Text('Anterior', style: estiloCabecera),
          Text('Variación', style: estiloCabecera),
        ]),
        for (final (nombre, actual, anterior, variacion) in filas)
          TableRow(children: [
            Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text(nombre)),
            Text(actual),
            Text(anterior),
            _Variacion(variacion),
          ]),
      ],
    );
  }
}

/// Muestra la variación con flecha + texto (nunca solo con color).
class _Variacion extends StatelessWidget {
  const _Variacion(this.valor);

  final double? valor;

  @override
  Widget build(BuildContext context) {
    final v = valor;
    if (v == null) return const Text('—');
    final sube = v >= 0;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(sube ? Icons.arrow_upward : Icons.arrow_downward, size: 14),
        Flexible(child: Text('${sube ? '+' : ''}${v.toStringAsFixed(1)} %')),
      ],
    );
  }
}

// ═══════════════════════════ Pestaña PRODUCTOS ═══════════════════════════

class _TabProductos extends StatelessWidget {
  const _TabProductos({required this.delPeriodo, required this.productos});

  final List<Venta> delPeriodo;
  final List<Producto> productos;

  @override
  Widget build(BuildContext context) {
    final porUnidades = rankingPorUnidades(delPeriodo);
    final porIngresos = rankingPorIngresos(delPeriodo);
    final categorias = ingresosPorCategoria(delPeriodo);
    final pctCategorias = porcentajes(categorias);
    final stockBajo = productosStockBajo(productos);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _Seccion(
          titulo: 'Unidades vendidas por producto (ranking)',
          child: BarrasHorizontales(
            datos: [
              for (final p in porUnidades) DatoGrafico(p.nombre, p.unidades.toDouble()),
            ],
            formatearValor: (v) => '${v.toInt()} u.',
          ),
        ),
        _Seccion(
          titulo: 'Ranking por ingresos',
          child: BarrasHorizontales(
            datos: [
              for (final p in porIngresos)
                DatoGrafico(p.nombre, p.ingresosCentimos / 100,
                    detalle: 'margen ${formatearSoles(p.margenCentimos)}'),
            ],
            formatearValor: formatearSolesDecimal,
          ),
        ),
        _Seccion(
          titulo: 'Ingresos por categoría',
          child: BarrasHorizontales(
            datos: [
              for (final e in categorias.entries)
                DatoGrafico(e.key, e.value / 100,
                    detalle: formatearPorcentaje(pctCategorias[e.key] ?? 0)),
            ],
            formatearValor: formatearSolesDecimal,
          ),
        ),
        _Seccion(
          titulo: 'Productos con stock bajo (${stockBajo.length})',
          child: stockBajo.isEmpty
              ? const Text('Ningún producto está por debajo de su stock mínimo.')
              : Column(children: [
                  for (final p in stockBajo)
                    _Fila(p.nombre, '${p.stock} u. (mín. ${p.stockMinimo})'),
                ]),
        ),
      ],
    );
  }
}

// ═══════════════════════════ Pestaña ESTADÍSTICA ═══════════════════════════

class _TabEstadistica extends StatelessWidget {
  const _TabEstadistica({required this.delPeriodo});

  final List<Venta> delPeriodo;

  @override
  Widget build(BuildContext context) {
    final importes = ResumenEstadistico.de(importesDeVentas(delPeriodo));
    final unidades = ResumenEstadistico.de(unidadesPorVenta(delPeriodo));
    final productos = frecuenciaProductos(delPeriodo);
    final pctProductos = porcentajes(productos);

    String soles(double? v) => v == null ? '—' : formatearSolesDecimal(v);
    String numero(num? v) => v == null ? '—' : formatearDecimal(v.toDouble());

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _Seccion(
          titulo: 'X · Importe de cada venta (S/)',
          child: Column(children: [
            _Fila('n (ventas confirmadas)', '${importes.n}'),
            _Fila('Media', soles(importes.media)),
            _Fila('Mediana', soles(importes.mediana)),
            _Fila('Mínimo', soles(importes.minimo?.toDouble())),
            _Fila('Máximo', soles(importes.maximo?.toDouble())),
            _Fila('Varianza poblacional σ² (S/²)', numero(importes.varianzaPoblacional)),
            _Fila('Varianza muestral s² (S/²)', numero(importes.varianzaMuestral)),
            _Fila('Desviación estándar poblacional σ', soles(importes.desviacionPoblacional)),
            _Fila('Desviación estándar muestral s', soles(importes.desviacionMuestral)),
            if (importes.n < 2)
              const _Nota('Los valores muestrales necesitan al menos 2 ventas.'),
          ]),
        ),
        _Seccion(
          titulo: 'U · Unidades por venta',
          child: Column(children: [
            _Fila('Promedio de unidades por venta', numero(unidades.media)),
            _Fila('Mediana', numero(unidades.mediana)),
            _Fila('Mínimo – máximo',
                unidades.n == 0 ? '—' : '${unidades.minimo} – ${unidades.maximo}'),
          ]),
        ),
        _Seccion(
          titulo: 'P · Frecuencia de productos (unidades)',
          child: productos.isEmpty
              ? const Text('Sin ventas en este período')
              : Column(children: [
                  for (final e in productos.entries)
                    _Fila(e.key,
                        '${e.value} u. · ${formatearPorcentaje(pctProductos[e.key]!)}'),
                ]),
        ),
        const _Seccion(
          titulo: 'Cómo se calculan',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Media x̄ = Σxᵢ / n\n'
                  'Mediana = valor central de los datos ordenados\n'
                  'Varianza poblacional σ² = Σ(xᵢ − x̄)² / n\n'
                  'Varianza muestral s² = Σ(xᵢ − x̄)² / (n − 1)\n'
                  'Desviación estándar = √varianza\n'
                  'Porcentaje = frecuencia / total × 100'),
              SizedBox(height: 8),
              _Nota('Los productos son datos CATEGÓRICOS: se resumen con '
                  'frecuencias y porcentajes, nunca con media ni varianza. '
                  'Los importes (S/) y las unidades se analizan por separado.'),
            ],
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════ Piezas comunes ═══════════════════════════

class _Seccion extends StatelessWidget {
  const _Seccion({required this.titulo, required this.child});

  final String titulo;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(titulo, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}

class _Fila extends StatelessWidget {
  const _Fila(this.etiqueta, this.valor, {this.destacado = false});

  final String etiqueta;
  final String valor;
  final bool destacado;

  @override
  Widget build(BuildContext context) {
    final estilo = destacado
        ? Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold)
        : Theme.of(context).textTheme.bodyMedium;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: Text(etiqueta, style: estilo)),
          const SizedBox(width: 8),
          Text(valor, style: estilo?.copyWith(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _Nota extends StatelessWidget {
  const _Nota(this.texto);

  final String texto;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: colores.secondaryContainer,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(texto,
          style: TextStyle(color: colores.onSecondaryContainer, fontSize: 12)),
    );
  }
}
