import 'package:flutter/material.dart';

import 'package:smartventas/services/auth_service.dart';

/// Botón con la inicial del usuario. Al tocarlo muestra su nombre, su rol
/// y la opción "Cerrar sesión" (solo si la app usa login).
class MenuUsuario extends StatelessWidget {
  const MenuUsuario({
    super.key,
    required this.usuario,
    required this.authService,
  });

  final Usuario usuario;
  final AuthService authService;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final inicial =
        usuario.nombre.isEmpty ? '?' : usuario.nombre[0].toUpperCase();

    return PopupMenuButton<String>(
      tooltip: 'Cuenta',
      onSelected: (opcion) {
        if (opcion == 'salir') authService.cerrarSesion();
      },
      itemBuilder: (context) => [
        PopupMenuItem(
          enabled: false,
          child: ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(usuario.nombre),
            subtitle: Text(
              '${usuario.correo}\n'
              'Rol: ${usuario.esAdmin ? 'Administrador' : 'Vendedor'}',
            ),
          ),
        ),
        if (authService.requiereLogin) ...[
          const PopupMenuDivider(),
          const PopupMenuItem(
            value: 'salir',
            child: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.logout),
              title: Text('Cerrar sesión'),
            ),
          ),
        ],
      ],
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: CircleAvatar(
          radius: 16,
          backgroundColor: colores.primary,
          foregroundColor: colores.onPrimary,
          child: Text(inicial),
        ),
      ),
    );
  }
}
