import 'package:smartventas/models/conversion.dart';
import 'package:smartventas/models/detalle_venta.dart';

/// Estado de una venta. Una venta confirmada solo puede pasar a anulada.
enum EstadoVenta { confirmada, anulada }

/// Una venta registrada, con sus líneas de detalle.
///
/// En Firestore se guarda como ventas/{id} y los detalles van DENTRO del
/// mismo documento (lista "detalles"), así la venta completa se guarda en
/// una sola escritura.
class Venta {
  const Venta({
    required this.id,
    required this.numero,
    required this.fecha,
    required this.detalles,
    this.estado = EstadoVenta.confirmada,
    this.vendedorUid,
    this.esDemo = false,
    this.fechaAnulacion,
  });

  /// Id del documento. También sirve como "llave de idempotencia" para
  /// que un doble toque no registre la misma venta dos veces.
  final String id;

  /// Número correlativo: 1, 2, 3...
  final int numero;
  final DateTime fecha;
  final List<DetalleVenta> detalles;
  final EstadoVenta estado;
  final String? vendedorUid;
  final bool esDemo;
  final DateTime? fechaAnulacion;

  // ───────────── Valores calculados ─────────────

  /// Código legible: número 42 → "V-000042".
  String get codigo => 'V-${numero.toString().padLeft(6, '0')}';

  bool get estaConfirmada => estado == EstadoVenta.confirmada;

  /// Total de la venta: suma de los subtotales.
  int get totalCentimos =>
      detalles.fold(0, (suma, detalle) => suma + detalle.subtotalCentimos);

  /// Costo estimado de los productos vendidos en esta venta.
  int get costoTotalCentimos =>
      detalles.fold(0, (suma, detalle) => suma + detalle.costoCentimos);

  /// Margen bruto estimado = total − costo estimado.
  int get margenBrutoCentimos => totalCentimos - costoTotalCentimos;

  /// Unidades vendidas en esta venta.
  int get unidadesTotales =>
      detalles.fold(0, (suma, detalle) => suma + detalle.cantidad);

  Venta copyWith({EstadoVenta? estado, DateTime? fechaAnulacion}) {
    return Venta(
      id: id,
      numero: numero,
      fecha: fecha,
      detalles: detalles,
      estado: estado ?? this.estado,
      vendedorUid: vendedorUid,
      esDemo: esDemo,
      fechaAnulacion: fechaAnulacion ?? this.fechaAnulacion,
    );
  }

  // ───────────── Conversión para Firestore ─────────────

  Map<String, dynamic> toMap() {
    return {
      'numero': numero,
      'fecha': fecha,
      'estado': estado.name, // "confirmada" o "anulada"
      // Los totales se guardan además de calcularse, para ordenar,
      // filtrar y revisarlos en la consola sin abrir los detalles.
      'totalCentimos': totalCentimos,
      'costoTotalCentimos': costoTotalCentimos,
      'unidadesTotales': unidadesTotales,
      'detalles': detalles.map((detalle) => detalle.toMap()).toList(),
      'vendedorUid': vendedorUid,
      'esDemo': esDemo,
      'fechaAnulacion': fechaAnulacion,
    };
  }

  factory Venta.fromMap(String id, Map<String, dynamic> datos) {
    final listaDetalles = (datos['detalles'] as List<dynamic>? ?? [])
        .map((d) => DetalleVenta.fromMap(Map<String, dynamic>.from(d as Map)))
        .toList();

    return Venta(
      id: id,
      numero: enteroDesdeValor(datos['numero']),
      fecha: fechaDesdeValor(datos['fecha']),
      detalles: listaDetalles,
      estado: EstadoVenta.values.firstWhere(
        (e) => e.name == datos['estado'],
        orElse: () => EstadoVenta.confirmada,
      ),
      vendedorUid: datos['vendedorUid'] as String?,
      esDemo: datos['esDemo'] as bool? ?? false,
      fechaAnulacion: fechaOpcionalDesdeValor(datos['fechaAnulacion']),
    );
  }

  @override
  String toString() => 'Venta($codigo, total: $totalCentimos, $estado)';
}
