import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'package:smartventas/app.dart';
import 'package:smartventas/config.dart';
import 'package:smartventas/firebase_options.dart';
import 'package:smartventas/services/servicios.dart';

/// Punto de entrada de la aplicación.
///
/// - MODO FIREBASE (AppConfig.usarFirebase = true): inicializa Firebase con
///   las claves de lib/firebase_options.dart (generado por
///   `flutterfire configure`) y usa Firestore + Authentication.
/// - MODO DEMO (false): datos ficticios en memoria, sin login.
Future<void> main() async {
  // Necesario antes de usar plugins (como Firebase) en main().
  WidgetsFlutterBinding.ensureInitialized();

  final Servicios servicios;
  if (AppConfig.usarFirebase) {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    servicios = Servicios.firebase();
  } else {
    // Retraso de 400 ms para simular la red y ver los indicadores de carga.
    servicios = Servicios.demo(latencia: const Duration(milliseconds: 400));
  }

  runApp(SmartVentasApp(servicios: servicios));
}
