import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:smartventas/models/carrito.dart';
import 'package:smartventas/models/producto.dart';
import 'package:smartventas/screens/comprobante_screen.dart';
import 'package:smartventas/services/excepciones.dart';
import 'package:smartventas/services/producto_service.dart';
import 'package:smartventas/services/venta_service.dart';
import 'package:smartventas/utils/filtros_productos.dart';
import 'package:smartventas/utils/formato.dart';
import 'package:smartventas/widgets/estado_error.dart';
import 'package:smartventas/widgets/etiqueta_origen_datos.dart';

/// Registro de ventas: elegir producto → cantidad → carrito → confirmar.
class NuevaVentaScreen extends StatefulWidget {
  const NuevaVentaScreen({
    super.key,
    required this.productoService,
    required this.ventaService,
    this.vendedorUid,
  });

  final ProductoService productoService;
  final VentaService ventaService;

  /// Usuario que registra la venta (se guarda en ventas/{id}.vendedorUid).
  final String? vendedorUid;

  @override
  State<NuevaVentaScreen> createState() => _NuevaVentaScreenState();
}

class _NuevaVentaScreenState extends State<NuevaVentaScreen> {
  final Carrito _carrito = Carrito();
  final _cantidad = TextEditingController(text: '1');

  StreamSubscription<List<Producto>>? _suscripcion;
  List<Producto>? _productos; // null = todavía cargando
  Object? _errorCarga;

  Producto? _seleccionado;
  String? _errorAgregar;

  /// true desde que se toca "Confirmar" hasta que termina todo el proceso.
  /// Es la primera barrera contra el doble toque.
  bool _ocupado = false;

  /// true solo mientras se espera la respuesta del servicio.
  bool _registrando = false;

  @override
  void initState() {
    super.initState();
    _escucharProductos();
  }

  /// Se escucha el stream "a mano" (en vez de StreamBuilder) porque cada
  /// cambio de stock también debe actualizar el carrito.
  void _escucharProductos() {
    _suscripcion?.cancel();
    _suscripcion = widget.productoService.observarProductos().listen(
      (lista) {
        if (!mounted) return;
        setState(() {
          _productos = lista;
          _errorCarga = null;
          // Refresca el producto elegido (su stock pudo cambiar).
          final elegido = _seleccionado;
          if (elegido != null) {
            final actual = lista.where((p) => p.id == elegido.id).firstOrNull;
            _seleccionado = (actual != null && actual.activo) ? actual : null;
          }
        });
        _carrito.actualizarProductos(lista);
      },
      onError: (Object error) {
        if (mounted) setState(() => _errorCarga = error);
      },
    );
  }

  @override
  void dispose() {
    _suscripcion?.cancel();
    _carrito.dispose();
    _cantidad.dispose();
    super.dispose();
  }

  // ───────────── Acciones ─────────────

  Future<void> _elegirProducto() async {
    final activos = (_productos ?? []).where((p) => p.activo).toList();
    final elegido = await showModalBottomSheet<Producto>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _SelectorProducto(productos: activos, carrito: _carrito),
    );
    if (elegido == null) return;
    setState(() {
      _seleccionado = elegido;
      _cantidad.text = '1';
      _errorAgregar = null;
    });
  }

  void _cambiarCantidadAAgregar(int delta) {
    final actual = int.tryParse(_cantidad.text) ?? 0;
    final nueva = (actual + delta).clamp(1, cantidadMaximaCampo);
    _cantidad.text = '$nueva';
  }

  void _agregarAlCarrito() {
    final producto = _seleccionado;
    if (producto == null) {
      setState(() => _errorAgregar = 'Primero selecciona un producto');
      return;
    }
    final cantidad = int.tryParse(_cantidad.text.trim()) ?? 0;
    final error = _carrito.agregar(producto, cantidad);
    setState(() {
      _errorAgregar = error;
      if (error == null) {
        _seleccionado = null;
        _cantidad.text = '1';
      }
    });
  }

  void _cambiarLinea(ItemCarrito item, int nuevaCantidad) {
    final error = _carrito.cambiarCantidad(item.producto.id, nuevaCantidad);
    if (error != null) _mostrarMensaje(error, esError: true);
  }

  Future<void> _vaciar() async {
    final confirmado = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Vaciar carrito'),
        content: const Text('Se quitarán todos los productos del carrito.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Vaciar'),
          ),
        ],
      ),
    );
    if (confirmado == true) _carrito.vaciar();
  }

  Future<void> _confirmarVenta() async {
    // Barrera 1: si ya se está procesando, se ignora el segundo toque.
    if (_ocupado) return;

    // Validaciones antes de preguntar.
    if (_carrito.estaVacio) {
      _mostrarMensaje(const CarritoVacioException().mensaje, esError: true);
      return;
    }
    final problemas = _carrito.problemas;
    if (problemas.isNotEmpty) {
      _mostrarMensaje(problemas.first, esError: true);
      return;
    }

    _ocupado = true;
    try {
      final confirmado = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          icon: const Icon(Icons.point_of_sale),
          title: const Text('Confirmar venta'),
          content: Text(
            '${_carrito.items.length} productos · ${_carrito.unidades} unidades\n'
            'Total: ${formatearSoles(_carrito.totalCentimos)}',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Seguir vendiendo'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Confirmar'),
            ),
          ],
        ),
      );
      if (confirmado != true || !mounted) return;

      setState(() => _registrando = true);

      // Barrera 2: el ventaId del carrito es el mismo en cada reintento,
      // así el servicio no registra la venta dos veces.
      final venta = await widget.ventaService.registrarVenta(
        ventaId: _carrito.ventaId,
        cantidades: _carrito.cantidades,
        vendedorUid: widget.vendedorUid,
      );

      // Solo después de confirmar con éxito se vacía el carrito (y se
      // genera un id nuevo para la próxima venta).
      _carrito.vaciar();
      if (!mounted) return;
      setState(() => _registrando = false);

      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => ComprobanteScreen(venta: venta)),
      );
    } on SmartVentasException catch (error) {
      // Error de negocio (stock insuficiente, producto desactivado...).
      // El stock NO se modificó y el carrito se conserva.
      _mostrarMensaje(error.mensaje, esError: true);
    } catch (error) {
      _mostrarMensaje(
        'No se pudo registrar la venta. El carrito se conserva: puedes '
        'reintentar sin riesgo de duplicarla.',
        esError: true,
      );
    } finally {
      _ocupado = false;
      if (mounted && _registrando) setState(() => _registrando = false);
    }
  }

  void _mostrarMensaje(String mensaje, {bool esError = false}) {
    if (!mounted) return;
    final colores = Theme.of(context).colorScheme;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(mensaje),
        backgroundColor: esError ? colores.error : null,
      ));
  }

  // ───────────── Interfaz ─────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nueva venta'),
        actions: [
          const EtiquetaOrigenDatos(),
          ListenableBuilder(
            listenable: _carrito,
            builder: (context, _) => IconButton(
              tooltip: 'Vaciar carrito',
              icon: const Icon(Icons.remove_shopping_cart_outlined),
              onPressed: _carrito.estaVacio || _registrando ? null : _vaciar,
            ),
          ),
        ],
      ),
      body: _construirCuerpo(),
      bottomNavigationBar: ListenableBuilder(
        listenable: _carrito,
        builder: (context, _) => _BarraTotal(
          totalCentimos: _carrito.totalCentimos,
          unidades: _carrito.unidades,
          registrando: _registrando,
          alConfirmar:
              _carrito.estaVacio || _registrando ? null : _confirmarVenta,
        ),
      ),
    );
  }

  Widget _construirCuerpo() {
    if (_errorCarga != null) {
      return EstadoError(
        mensaje: 'No se pudieron cargar los productos.\n$_errorCarga',
        alReintentar: () {
          setState(() {
            _errorCarga = null;
            _productos = null;
          });
          _escucharProductos();
        },
      );
    }
    if (_productos == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return ListenableBuilder(
      listenable: _carrito,
      builder: (context, _) {
        final textos = Theme.of(context).textTheme;
        final items = _carrito.items;
        final problemas = _carrito.problemas;

        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            _construirTarjetaAgregar(),
            const SizedBox(height: 20),
            Text('Carrito (${items.length})', style: textos.titleMedium),
            const SizedBox(height: 8),
            for (final problema in problemas) _AvisoProblema(texto: problema),
            if (items.isEmpty)
              const _CarritoVacio()
            else
              for (final item in items)
                _LineaCarrito(
                  item: item,
                  habilitada: !_registrando,
                  alRestar: () => _cambiarLinea(item, item.cantidad - 1),
                  alSumar: () => _cambiarLinea(item, item.cantidad + 1),
                  alQuitar: () => _carrito.quitar(item.producto.id),
                ),
          ],
        );
      },
    );
  }

  Widget _construirTarjetaAgregar() {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;
    final producto = _seleccionado;
    final enCarrito = producto == null ? 0 : _carrito.cantidadDe(producto.id);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Agregar producto', style: textos.titleMedium),
            const SizedBox(height: 12),
            // InputDecorator da el aspecto de un campo, pero abre el selector.
            InkWell(
              onTap: _registrando ? null : _elegirProducto,
              borderRadius: BorderRadius.circular(4),
              child: InputDecorator(
                decoration: const InputDecoration(
                  labelText: 'Producto',
                  prefixIcon: Icon(Icons.inventory_2_outlined),
                  suffixIcon: Icon(Icons.arrow_drop_down),
                ),
                child: Text(
                  producto?.nombre ?? 'Toca para elegir',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: producto == null
                      ? TextStyle(color: colores.onSurfaceVariant)
                      : null,
                ),
              ),
            ),
            if (producto != null) ...[
              const SizedBox(height: 8),
              Text(
                '${formatearSoles(producto.precioCentimos)} c/u · '
                'Disponible: ${producto.stock}'
                '${enCarrito > 0 ? ' (en carrito: $enCarrito)' : ''}',
                style: textos.bodySmall,
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                IconButton.outlined(
                  tooltip: 'Menos',
                  onPressed: () => _cambiarCantidadAAgregar(-1),
                  icon: const Icon(Icons.remove),
                ),
                SizedBox(
                  width: 64,
                  child: TextField(
                    key: const Key('cantidadAgregar'),
                    controller: _cantidad,
                    textAlign: TextAlign.center,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(5),
                    ],
                    decoration: const InputDecoration(isDense: true),
                  ),
                ),
                IconButton.outlined(
                  tooltip: 'Más',
                  onPressed: () => _cambiarCantidadAAgregar(1),
                  icon: const Icon(Icons.add),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: _registrando ? null : _agregarAlCarrito,
                    icon: const Icon(Icons.add_shopping_cart),
                    label: const Text('Agregar'),
                  ),
                ),
              ],
            ),
            if (_errorAgregar != null) ...[
              const SizedBox(height: 8),
              Text(_errorAgregar!, style: TextStyle(color: colores.error)),
            ],
          ],
        ),
      ),
    );
  }
}

/// Tope del campo de cantidad (5 dígitos).
const int cantidadMaximaCampo = 99999;

// ───────────── Widgets privados ─────────────

class _CarritoVacio extends StatelessWidget {
  const _CarritoVacio();

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 32),
      child: Column(
        children: [
          Icon(Icons.shopping_cart_outlined, size: 56, color: colores.outline),
          const SizedBox(height: 8),
          Text('El carrito está vacío',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(
            'Elige un producto y su cantidad para empezar.',
            style: TextStyle(color: colores.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

class _AvisoProblema extends StatelessWidget {
  const _AvisoProblema({required this.texto});

  final String texto;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    return Card(
      color: colores.errorContainer,
      child: ListTile(
        dense: true,
        leading: Icon(Icons.warning_amber, color: colores.onErrorContainer),
        title: Text(texto, style: TextStyle(color: colores.onErrorContainer)),
      ),
    );
  }
}

class _LineaCarrito extends StatelessWidget {
  const _LineaCarrito({
    required this.item,
    required this.habilitada,
    required this.alRestar,
    required this.alSumar,
    required this.alQuitar,
  });

  final ItemCarrito item;
  final bool habilitada;
  final VoidCallback alRestar;
  final VoidCallback alSumar;
  final VoidCallback alQuitar;

  @override
  Widget build(BuildContext context) {
    final textos = Theme.of(context).textTheme;
    final producto = item.producto;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 4, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(producto.nombre, style: textos.titleSmall),
                ),
                IconButton(
                  tooltip: 'Quitar del carrito',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: habilitada ? alQuitar : null,
                ),
              ],
            ),
            Row(
              children: [
                IconButton(
                  tooltip: 'Restar uno',
                  icon: const Icon(Icons.remove_circle_outline),
                  // Con 1 unidad no se resta: para quitar se usa la papelera.
                  onPressed: habilitada && item.cantidad > 1 ? alRestar : null,
                ),
                Text('${item.cantidad}', style: textos.titleMedium),
                IconButton(
                  tooltip: 'Sumar uno',
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed: habilitada ? alSumar : null,
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    '× ${formatearSoles(producto.precioCentimos)}',
                    style: textos.bodySmall,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Text(
                    formatearSoles(item.subtotalCentimos),
                    style: textos.titleMedium
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _BarraTotal extends StatelessWidget {
  const _BarraTotal({
    required this.totalCentimos,
    required this.unidades,
    required this.registrando,
    required this.alConfirmar,
  });

  final int totalCentimos;
  final int unidades;
  final bool registrando;
  final VoidCallback? alConfirmar;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;

    return Material(
      color: colores.surfaceContainer,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Total ($unidades unidades)', style: textos.bodySmall),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                        formatearSoles(totalCentimos),
                        key: const Key('totalVenta'),
                        style: textos.headlineSmall
                            ?.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
              FilledButton.icon(
                onPressed: alConfirmar,
                icon: registrando
                    ? const SizedBox.square(
                        dimension: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.check),
                label: Text(registrando ? 'Registrando…' : 'Confirmar venta'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Hoja inferior para buscar y elegir un producto activo.
class _SelectorProducto extends StatefulWidget {
  const _SelectorProducto({required this.productos, required this.carrito});

  final List<Producto> productos;
  final Carrito carrito;

  @override
  State<_SelectorProducto> createState() => _SelectorProductoState();
}

class _SelectorProductoState extends State<_SelectorProducto> {
  String _texto = '';

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final visibles = filtrarProductos(widget.productos, texto: _texto);

    return FractionallySizedBox(
      heightFactor: 0.85,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              autofocus: true,
              decoration: const InputDecoration(
                hintText: 'Buscar producto',
                prefixIcon: Icon(Icons.search),
                isDense: true,
              ),
              onChanged: (valor) => setState(() => _texto = valor),
            ),
          ),
          Expanded(
            child: visibles.isEmpty
                ? const Center(child: Text('Sin productos disponibles'))
                : ListView.builder(
                    itemCount: visibles.length,
                    itemBuilder: (context, indice) {
                      final p = visibles[indice];
                      final enCarrito = widget.carrito.cantidadDe(p.id);
                      final quedan = p.stock - enCarrito;
                      return ListTile(
                        enabled: quedan > 0,
                        title: Text(p.nombre),
                        subtitle: Text(
                          '${formatearSoles(p.precioCentimos)} · stock ${p.stock}'
                          '${enCarrito > 0 ? ' · en carrito $enCarrito' : ''}',
                        ),
                        trailing: quedan > 0
                            ? (p.stockBajo
                                ? Icon(Icons.warning_amber, color: colores.error)
                                : null)
                            : Text('Agotado',
                                style: TextStyle(color: colores.error)),
                        onTap: () => Navigator.pop(context, p),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
