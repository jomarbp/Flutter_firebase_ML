import 'dart:async';

import 'package:smartventas/models/detalle_venta.dart';
import 'package:smartventas/models/producto.dart';
import 'package:smartventas/models/venta.dart';
import 'package:smartventas/services/excepciones.dart';
import 'package:smartventas/services/producto_service.dart';
import 'package:smartventas/services/venta_service.dart';
import 'package:smartventas/utils/formato.dart';
import 'package:smartventas/utils/validaciones.dart';

/// Servicio de productos que guarda todo EN MEMORIA (modo DEMO).
///
/// - No necesita internet ni Firebase.
/// - Los cambios se pierden al cerrar la app.
/// - Aplica las MISMAS reglas que la versión de Firestore (validación,
///   nombre único, desactivar en vez de borrar si hay ventas), por eso
///   sirve también para las pruebas automáticas.
class MemoriaProductoService implements ProductoService {
  MemoriaProductoService({
    List<Producto> productosIniciales = const [],
    this.latencia = Duration.zero,
  }) : _productos = {for (final p in productosIniciales) p.id: p};

  /// Retraso artificial para simular la red y poder ver los indicadores
  /// de carga. En las pruebas se deja en cero.
  final Duration latencia;

  /// Productos guardados, por id. Un Map de Dart conserva el orden
  /// en que se insertaron los elementos.
  final Map<String, Producto> _productos;

  /// "Altavoz" que avisa a quien esté escuchando que la lista cambió.
  /// broadcast = permite varios oyentes a la vez.
  final StreamController<List<Producto>> _cambios =
      StreamController<List<Producto>>.broadcast();

  int _contadorIds = 0;

  // ───────────── Ayudantes privados ─────────────

  List<Producto> _copiaActual() => List.unmodifiable(_productos.values);

  void _notificarCambio() => _cambios.add(_copiaActual());

  Future<void> _simularRed() async {
    if (latencia > Duration.zero) await Future<void>.delayed(latencia);
  }

  String _nuevoId() {
    _contadorIds++;
    return 'p${DateTime.now().microsecondsSinceEpoch}_$_contadorIds';
  }

  Producto _buscarOFallar(String id) {
    final producto = _productos[id];
    if (producto == null) throw ProductoNoEncontradoException(id);
    return producto;
  }

  void _validar(Producto producto) {
    final errores = validarProducto(producto);
    if (errores.isNotEmpty) throw DatosInvalidosException(errores);
  }

  /// Impide dos productos con el mismo nombre (sin importar mayúsculas
  /// ni tildes). [exceptoId] permite guardar el mismo producto al editarlo.
  void _verificarNombreUnico(String nombre, {String? exceptoId}) {
    final buscado = normalizarTexto(nombre.trim());
    final repetido = _productos.values.any(
      (p) => p.id != exceptoId && normalizarTexto(p.nombre) == buscado,
    );
    if (repetido) throw ProductoDuplicadoException(nombre.trim());
  }

  // ───────────── Implementación de la interfaz ─────────────

  @override
  Stream<List<Producto>> observarProductos() async* {
    await _simularRed();
    yield _copiaActual(); // primero, la lista actual
    yield* _cambios.stream; // después, cada cambio
  }

  @override
  Future<List<Producto>> obtenerProductos() async {
    await _simularRed();
    return _copiaActual();
  }

  @override
  Future<Producto?> obtenerProducto(String id) async {
    await _simularRed();
    return _productos[id];
  }

  @override
  Future<Producto> crearProducto(Producto borrador) async {
    await _simularRed();
    final producto = borrador.copyWith(
      id: _nuevoId(),
      nombre: borrador.nombre.trim(),
      fechaCreacion: DateTime.now(),
      activo: true,
      tieneVentas: false,
      esDemo: false,
    );
    _validar(producto);
    _verificarNombreUnico(producto.nombre);

    _productos[producto.id] = producto;
    _notificarCambio();
    return producto;
  }

  @override
  Future<void> actualizarProducto(Producto producto) async {
    await _simularRed();
    final actual = _buscarOFallar(producto.id);
    // Estos campos NO se cambian desde el formulario: se conservan.
    final actualizado = producto.copyWith(
      nombre: producto.nombre.trim(),
      fechaCreacion: actual.fechaCreacion,
      tieneVentas: actual.tieneVentas,
      esDemo: actual.esDemo,
    );
    _validar(actualizado);
    _verificarNombreUnico(actualizado.nombre, exceptoId: actualizado.id);

    _productos[actualizado.id] = actualizado;
    _notificarCambio();
  }

  @override
  Future<ResultadoEliminacion> eliminarProducto(String id) async {
    await _simularRed();
    final producto = _buscarOFallar(id);

    if (producto.tieneVentas) {
      // Política: con ventas → se conserva como inactivo.
      _productos[id] = producto.copyWith(activo: false);
      _notificarCambio();
      return ResultadoEliminacion.desactivado;
    }

    _productos.remove(id);
    _notificarCambio();
    return ResultadoEliminacion.eliminado;
  }

  @override
  Future<void> reactivarProducto(String id) async {
    await _simularRed();
    final producto = _buscarOFallar(id);
    _productos[id] = producto.copyWith(activo: true);
    _notificarCambio();
  }

  /// Libera el StreamController (se usa en las pruebas).
  void cerrar() => _cambios.close();
}

/// Servicio de ventas EN MEMORIA (modo DEMO).
///
/// Comparte los productos con [MemoriaProductoService] para poder
/// descontar y devolver stock. Como ambas clases están en el MISMO archivo,
/// esta clase puede usar los miembros privados (_productos) de la otra:
/// en Dart, lo privado es privado por archivo, no por clase.
///
/// ¿Cómo se logra "todo o nada" sin una base de datos?
/// Dart ejecuta el código de forma secuencial en un solo hilo. Entre la
/// VALIDACIÓN y la ESCRITURA no hay ningún `await`, así que ninguna otra
/// venta puede ejecutarse en medio. Es el equivalente en memoria de una
/// transacción de Firestore.
class MemoriaVentaService implements VentaService {
  MemoriaVentaService({
    required MemoriaProductoService productos,
    List<Venta> ventasIniciales = const [],
    this.latencia = Duration.zero,
  })  : _servicioProductos = productos,
        _ventas = {for (final v in ventasIniciales) v.id: v},
        _ultimoNumero = ventasIniciales.fold(
            0, (maximo, v) => v.numero > maximo ? v.numero : maximo);

  final MemoriaProductoService _servicioProductos;
  final Map<String, Venta> _ventas;
  final Duration latencia;

  /// Equivale al documento contadores/ventas de Firestore.
  int _ultimoNumero;

  final StreamController<List<Venta>> _cambios =
      StreamController<List<Venta>>.broadcast();

  /// Ventas de la más reciente a la más antigua.
  List<Venta> _copiaOrdenada() {
    final lista = _ventas.values.toList()
      ..sort((a, b) => b.fecha.compareTo(a.fecha));
    return List.unmodifiable(lista);
  }

  void _notificar() => _cambios.add(_copiaOrdenada());

  Future<void> _simularRed() async {
    if (latencia > Duration.zero) await Future<void>.delayed(latencia);
  }

  @override
  Future<Venta> registrarVenta({
    required String ventaId,
    required Map<String, int> cantidades,
    String? vendedorUid,
  }) async {
    await _simularRed();
    // ── A partir de aquí NO hay ningún await: todo ocurre "de golpe". ──

    // 1) Idempotencia: si esta venta ya se registró (doble toque o
    //    reintento), se devuelve la misma sin descontar stock otra vez.
    final existente = _ventas[ventaId];
    if (existente != null) return existente;

    // 2) Validar TODAS las líneas antes de modificar nada.
    if (cantidades.isEmpty) throw const CarritoVacioException();

    final productos = _servicioProductos._productos;
    final detalles = <DetalleVenta>[];
    for (final MapEntry(key: productoId, value: cantidad) in cantidades.entries) {
      final producto = productos[productoId];
      if (producto == null) throw ProductoNoEncontradoException(productoId);
      if (!producto.activo) throw ProductoInactivoException(producto.nombre);
      if (cantidad <= 0) {
        throw DatosInvalidosException(
            ['La cantidad de "${producto.nombre}" debe ser mayor que cero']);
      }
      if (cantidad > producto.stock) {
        throw StockInsuficienteException(
          nombreProducto: producto.nombre,
          disponible: producto.stock,
          solicitado: cantidad,
        );
      }
      // Copia del precio, nombre y costo de ESTE momento.
      detalles.add(DetalleVenta.desdeProducto(producto, cantidad));
    }

    // 3) Escribir: descontar stock, numerar y guardar la venta.
    for (final detalle in detalles) {
      final producto = productos[detalle.productoId]!;
      productos[producto.id] = producto.copyWith(
        stock: producto.stock - detalle.cantidad,
        tieneVentas: true,
      );
    }
    _ultimoNumero++;
    final venta = Venta(
      id: ventaId,
      numero: _ultimoNumero,
      fecha: DateTime.now(),
      detalles: detalles,
      vendedorUid: vendedorUid,
    );
    _ventas[ventaId] = venta;

    _servicioProductos._notificarCambio();
    _notificar();
    return venta;
  }

  @override
  Stream<List<Venta>> observarVentas() async* {
    await _simularRed();
    yield _copiaOrdenada();
    yield* _cambios.stream;
  }

  @override
  Future<Venta?> obtenerVenta(String id) async {
    await _simularRed();
    return _ventas[id];
  }

  @override
  Future<Venta> anularVenta(String ventaId) async {
    await _simularRed();
    final venta = _ventas[ventaId];
    if (venta == null) throw VentaNoEncontradaException(ventaId);

    // Si ya está anulada, no se devuelve el stock otra vez.
    if (!venta.estaConfirmada) return venta;

    final productos = _servicioProductos._productos;
    for (final detalle in venta.detalles) {
      final producto = productos[detalle.productoId];
      // Si el producto se eliminó, no hay stock que devolver.
      if (producto == null) continue;
      productos[producto.id] =
          producto.copyWith(stock: producto.stock + detalle.cantidad);
    }

    final anulada = venta.copyWith(
      estado: EstadoVenta.anulada,
      fechaAnulacion: DateTime.now(),
    );
    _ventas[ventaId] = anulada;

    _servicioProductos._notificarCambio();
    _notificar();
    return anulada;
  }

  void cerrar() => _cambios.close();
}
