import 'package:smartventas/models/conversion.dart';
import 'package:smartventas/models/producto.dart';

/// Una línea de una venta: qué producto, cuántas unidades y a qué precio.
///
/// Guarda una COPIA del nombre, la categoría, el precio y el costo del
/// producto EN EL MOMENTO DE LA VENTA. Si mañana cambia el precio del
/// producto, esta venta sigue mostrando el precio con el que se vendió.
class DetalleVenta {
  const DetalleVenta({
    required this.productoId,
    required this.nombreProducto,
    required this.categoria,
    required this.precioUnitarioCentimos,
    required this.costoUnitarioCentimos,
    required this.cantidad,
  });

  /// Crea la línea copiando los datos actuales del producto.
  factory DetalleVenta.desdeProducto(Producto producto, int cantidad) {
    return DetalleVenta(
      productoId: producto.id,
      nombreProducto: producto.nombre,
      categoria: producto.categoria,
      precioUnitarioCentimos: producto.precioCentimos,
      costoUnitarioCentimos: producto.costoCentimos,
      cantidad: cantidad,
    );
  }

  final String productoId;
  final String nombreProducto;
  final String categoria;
  final int precioUnitarioCentimos;
  final int costoUnitarioCentimos;
  final int cantidad;

  /// Subtotal = precio unitario × cantidad (entero exacto).
  int get subtotalCentimos => precioUnitarioCentimos * cantidad;

  /// Costo estimado de esta línea.
  int get costoCentimos => costoUnitarioCentimos * cantidad;

  /// Margen bruto estimado de esta línea.
  int get margenCentimos => subtotalCentimos - costoCentimos;

  Map<String, dynamic> toMap() {
    return {
      'productoId': productoId,
      'nombreProducto': nombreProducto,
      'categoria': categoria,
      'precioUnitarioCentimos': precioUnitarioCentimos,
      'costoUnitarioCentimos': costoUnitarioCentimos,
      'cantidad': cantidad,
      // Se guarda también el subtotal para leerlo fácilmente en la consola.
      'subtotalCentimos': subtotalCentimos,
    };
  }

  factory DetalleVenta.fromMap(Map<String, dynamic> datos) {
    return DetalleVenta(
      productoId: datos['productoId'] as String? ?? '',
      nombreProducto: datos['nombreProducto'] as String? ?? '',
      categoria: datos['categoria'] as String? ?? 'Otros',
      precioUnitarioCentimos: enteroDesdeValor(datos['precioUnitarioCentimos']),
      costoUnitarioCentimos: enteroDesdeValor(datos['costoUnitarioCentimos']),
      cantidad: enteroDesdeValor(datos['cantidad']),
    );
  }
}
