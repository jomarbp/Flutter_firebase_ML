import 'package:flutter/material.dart';

import 'package:smartventas/models/producto.dart';
import 'package:smartventas/screens/producto_form_screen.dart';
import 'package:smartventas/services/excepciones.dart';
import 'package:smartventas/services/producto_service.dart';
import 'package:smartventas/utils/filtros_productos.dart';
import 'package:smartventas/utils/formato.dart';
import 'package:smartventas/widgets/estado_error.dart';
import 'package:smartventas/widgets/estado_vacio.dart';
import 'package:smartventas/widgets/etiqueta_origen_datos.dart';

/// Gestión de productos: lista, búsqueda, filtro, orden, registro,
/// edición y eliminación/desactivación.
class ProductosScreen extends StatefulWidget {
  const ProductosScreen({
    super.key,
    required this.productoService,
    this.puedeEditar = true,
  });

  final ProductoService productoService;

  /// false para el rol "vendedor": solo consulta, no registra ni edita.
  /// (Las reglas de Firestore también lo impiden en el servidor.)
  final bool puedeEditar;

  @override
  State<ProductosScreen> createState() => _ProductosScreenState();
}

class _ProductosScreenState extends State<ProductosScreen> {
  /// El stream se crea UNA vez (en initState) y no en build(): si se
  /// creara en build, cada redibujo abriría una suscripción nueva.
  late Stream<List<Producto>> _productos;

  final _busqueda = TextEditingController();
  String? _categoria; // null = todas
  OrdenProducto _orden = OrdenProducto.nombre;
  bool _incluirInactivos = false;

  @override
  void initState() {
    super.initState();
    _suscribir();
  }

  void _suscribir() {
    _productos = widget.productoService.observarProductos();
  }

  @override
  void dispose() {
    _busqueda.dispose();
    super.dispose();
  }

  void _limpiarFiltros() {
    _busqueda.clear();
    setState(() {
      _categoria = null;
      _incluirInactivos = false;
    });
  }

  // ───────────── Acciones ─────────────

  Future<void> _abrirFormulario({Producto? producto}) async {
    final mensaje = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => ProductoFormScreen(
          productoService: widget.productoService,
          producto: producto,
        ),
      ),
    );
    if (mensaje != null) _mostrarMensaje(mensaje);
  }

  Future<void> _confirmarEliminacion(Producto producto) async {
    final conVentas = producto.tieneVentas;

    final confirmado = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        icon: Icon(
          conVentas ? Icons.visibility_off_outlined : Icons.delete_outline,
        ),
        title: Text(conVentas ? 'Desactivar producto' : 'Eliminar producto'),
        content: Text(
          conVentas
              ? '"${producto.nombre}" tiene ventas registradas, por eso no se '
                    'puede borrar. Se DESACTIVARÁ: no aparecerá para vender, '
                    'pero el historial y los reportes se conservan. '
                    'Podrás reactivarlo después.'
              : '¿Eliminar "${producto.nombre}" definitivamente? '
                    'Esta acción no se puede deshacer.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            style: conVentas
                ? null
                : FilledButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.error,
                    foregroundColor: Theme.of(context).colorScheme.onError,
                  ),
            onPressed: () => Navigator.pop(context, true),
            child: Text(conVentas ? 'Desactivar' : 'Eliminar'),
          ),
        ],
      ),
    );
    if (confirmado != true) return;

    try {
      final resultado = await widget.productoService.eliminarProducto(
        producto.id,
      );
      _mostrarMensaje(
        resultado == ResultadoEliminacion.eliminado
            ? '"${producto.nombre}" eliminado'
            : '"${producto.nombre}" desactivado',
      );
    } on SmartVentasException catch (error) {
      _mostrarMensaje(error.mensaje, esError: true);
    }
  }

  Future<void> _reactivar(Producto producto) async {
    try {
      await widget.productoService.reactivarProducto(producto.id);
      _mostrarMensaje('"${producto.nombre}" reactivado');
    } on SmartVentasException catch (error) {
      _mostrarMensaje(error.mensaje, esError: true);
    }
  }

  void _mostrarMensaje(String mensaje, {bool esError = false}) {
    if (!mounted) return;
    final colores = Theme.of(context).colorScheme;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(mensaje),
          backgroundColor: esError ? colores.error : null,
        ),
      );
  }

  // ───────────── Interfaz ─────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Productos'),
        actions: [
          const EtiquetaOrigenDatos(),
          PopupMenuButton<OrdenProducto>(
            icon: const Icon(Icons.sort),
            tooltip: 'Ordenar',
            initialValue: _orden,
            onSelected: (orden) => setState(() => _orden = orden),
            itemBuilder: (context) => [
              for (final orden in OrdenProducto.values)
                PopupMenuItem(value: orden, child: Text(orden.etiqueta)),
            ],
          ),
        ],
      ),
      floatingActionButton: widget.puedeEditar
          ? FloatingActionButton.extended(
              onPressed: () => _abrirFormulario(),
              icon: const Icon(Icons.add),
              label: const Text('Nuevo'),
            )
          : null,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: TextField(
              controller: _busqueda,
              decoration: InputDecoration(
                hintText: 'Buscar por nombre',
                prefixIcon: const Icon(Icons.search),
                // ValueListenableBuilder muestra la "X" solo si hay texto.
                suffixIcon: ValueListenableBuilder(
                  valueListenable: _busqueda,
                  builder: (context, valor, _) => valor.text.isEmpty
                      ? const SizedBox.shrink()
                      : IconButton(
                          tooltip: 'Borrar búsqueda',
                          icon: const Icon(Icons.clear),
                          onPressed: () => setState(_busqueda.clear),
                        ),
                ),
                isDense: true,
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),
          _BarraFiltros(
            categoria: _categoria,
            incluirInactivos: _incluirInactivos,
            alCambiarCategoria: (c) => setState(() => _categoria = c),
            alCambiarInactivos: (v) => setState(() => _incluirInactivos = v),
          ),
          Expanded(child: _construirLista()),
        ],
      ),
    );
  }

  Widget _construirLista() {
    return StreamBuilder<List<Producto>>(
      stream: _productos,
      builder: (context, snapshot) {
        // 1) Error
        if (snapshot.hasError) {
          return EstadoError(
            mensaje: 'No se pudieron cargar los productos.\n${snapshot.error}',
            alReintentar: () => setState(_suscribir),
          );
        }
        // 2) Cargando
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final todos = snapshot.data!;
        // 3) Vacío: no hay ningún producto registrado
        if (todos.isEmpty) {
          return EstadoVacio(
            icono: Icons.inventory_2_outlined,
            titulo: 'Aún no hay productos',
            mensaje: 'Registra el primer producto de la tienda.',
            accion: widget.puedeEditar
                ? FilledButton.icon(
                    onPressed: () => _abrirFormulario(),
                    icon: const Icon(Icons.add),
                    label: const Text('Registrar producto'),
                  )
                : null,
          );
        }

        final visibles = filtrarProductos(
          todos,
          texto: _busqueda.text,
          categoria: _categoria,
          orden: _orden,
          incluirInactivos: _incluirInactivos,
        );
        // 4) Vacío: hay productos, pero ninguno cumple los filtros
        if (visibles.isEmpty) {
          return EstadoVacio(
            icono: Icons.search_off,
            titulo: 'Sin resultados',
            mensaje: 'Ningún producto coincide con la búsqueda o el filtro.',
            accion: OutlinedButton(
              onPressed: _limpiarFiltros,
              child: const Text('Limpiar filtros'),
            ),
          );
        }

        // 5) Con datos
        final stockBajo = visibles.where((p) => p.activo && p.stockBajo).length;
        return ListView.builder(
          // Espacio abajo para que el botón "Nuevo" no tape el último producto.
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 88),
          itemCount: visibles.length + 1,
          itemBuilder: (context, indice) {
            if (indice == 0) {
              return Padding(
                padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
                child: Text(
                  '${visibles.length} de ${todos.length} productos'
                  '${stockBajo > 0 ? ' · $stockBajo con stock bajo' : ''}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              );
            }
            final producto = visibles[indice - 1];
            return _TarjetaProducto(
              producto: producto,
              puedeEditar: widget.puedeEditar,
              alEditar: () => _abrirFormulario(producto: producto),
              alEliminar: () => _confirmarEliminacion(producto),
              alReactivar: () => _reactivar(producto),
            );
          },
        );
      },
    );
  }
}

// ───────────── Widgets privados de esta pantalla ─────────────

/// Fila desplazable con los filtros de categoría y "Inactivos".
class _BarraFiltros extends StatelessWidget {
  const _BarraFiltros({
    required this.categoria,
    required this.incluirInactivos,
    required this.alCambiarCategoria,
    required this.alCambiarInactivos,
  });

  final String? categoria;
  final bool incluirInactivos;
  final ValueChanged<String?> alCambiarCategoria;
  final ValueChanged<bool> alCambiarInactivos;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 48,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(
              label: const Text('Todas'),
              selected: categoria == null,
              onSelected: (_) => alCambiarCategoria(null),
            ),
          ),
          for (final c in categoriasProducto)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: ChoiceChip(
                label: Text(c),
                selected: categoria == c,
                onSelected: (_) => alCambiarCategoria(c),
              ),
            ),
          const VerticalDivider(indent: 12, endIndent: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: FilterChip(
              label: const Text('Inactivos'),
              avatar: const Icon(Icons.visibility_off_outlined, size: 18),
              selected: incluirInactivos,
              onSelected: alCambiarInactivos,
            ),
          ),
        ],
      ),
    );
  }
}

/// Icono para cada categoría.
IconData _iconoCategoria(String categoria) {
  return switch (categoria) {
    'Periféricos' => Icons.mouse_outlined,
    'Audio' => Icons.headphones_outlined,
    'Cables' => Icons.cable_outlined,
    'Energía' => Icons.battery_charging_full_outlined,
    'Almacenamiento' => Icons.sd_storage_outlined,
    'Accesorios' => Icons.devices_other_outlined,
    _ => Icons.category_outlined,
  };
}

enum _AccionProducto { editar, eliminar, reactivar }

class _TarjetaProducto extends StatelessWidget {
  const _TarjetaProducto({
    required this.producto,
    required this.puedeEditar,
    required this.alEditar,
    required this.alEliminar,
    required this.alReactivar,
  });

  final Producto producto;
  final bool puedeEditar;
  final VoidCallback alEditar;
  final VoidCallback alEliminar;
  final VoidCallback alReactivar;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;
    final inactivo = !producto.activo;

    return Opacity(
      opacity: inactivo ? 0.6 : 1,
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 4),
        child: ListTile(
          onTap: puedeEditar ? alEditar : null,
          contentPadding: const EdgeInsets.only(left: 12, right: 4),
          leading: CircleAvatar(
            backgroundColor: colores.primaryContainer,
            foregroundColor: colores.onPrimaryContainer,
            child: Icon(_iconoCategoria(producto.categoria)),
          ),
          title: Text(
            producto.nombre,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Wrap(
              spacing: 8,
              runSpacing: 4,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text(
                  formatearSoles(producto.precioCentimos),
                  style: textos.titleSmall?.copyWith(color: colores.primary),
                ),
                _ChipStock(producto: producto),
                if (inactivo)
                  Text(
                    'INACTIVO',
                    style: textos.labelSmall?.copyWith(color: colores.error),
                  ),
                if (producto.esDemo) Text('demo', style: textos.labelSmall),
              ],
            ),
          ),
          trailing: !puedeEditar
              ? null
              : PopupMenuButton<_AccionProducto>(
                  tooltip: 'Opciones',
                  onSelected: (accion) => switch (accion) {
                    _AccionProducto.editar => alEditar(),
                    _AccionProducto.eliminar => alEliminar(),
                    _AccionProducto.reactivar => alReactivar(),
                  },
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: _AccionProducto.editar,
                      child: ListTile(
                        leading: Icon(Icons.edit_outlined),
                        title: Text('Editar'),
                      ),
                    ),
                    if (producto.activo)
                      PopupMenuItem(
                        value: _AccionProducto.eliminar,
                        child: ListTile(
                          leading: Icon(
                            producto.tieneVentas
                                ? Icons.visibility_off_outlined
                                : Icons.delete_outline,
                          ),
                          title: Text(
                            producto.tieneVentas ? 'Desactivar' : 'Eliminar',
                          ),
                        ),
                      )
                    else
                      const PopupMenuItem(
                        value: _AccionProducto.reactivar,
                        child: ListTile(
                          leading: Icon(Icons.visibility_outlined),
                          title: Text('Reactivar'),
                        ),
                      ),
                  ],
                ),
        ),
      ),
    );
  }
}

/// "25 u." en gris, o "4 u. · bajo" en rojo si el stock está bajo.
class _ChipStock extends StatelessWidget {
  const _ChipStock({required this.producto});

  final Producto producto;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final bajo = producto.stockBajo;
    final texto = producto.agotado
        ? 'Agotado'
        : '${producto.stock} u.${bajo ? ' · stock bajo' : ''}';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: bajo ? colores.errorContainer : colores.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        texto,
        style: TextStyle(
          fontSize: 12,
          color: bajo ? colores.onErrorContainer : colores.onSurfaceVariant,
        ),
      ),
    );
  }
}
