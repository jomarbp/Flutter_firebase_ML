import 'package:flutter/material.dart';

/// Comparte con TODAS las pantallas de dónde vienen los datos.
///
/// Es un InheritedWidget: se coloca una vez arriba del árbol (en app.dart)
/// y cualquier widget de abajo lo lee con OrigenDatos.esFirebaseEn(context),
/// sin tener que pasarlo por cada constructor.
class OrigenDatos extends InheritedWidget {
  const OrigenDatos({
    super.key,
    required this.esFirebase,
    required super.child,
  });

  final bool esFirebase;

  /// Si no hay un OrigenDatos arriba (por ejemplo, en una prueba de una
  /// sola pantalla), se asume modo DEMO.
  static bool esFirebaseEn(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<OrigenDatos>()?.esFirebase ??
      false;

  @override
  bool updateShouldNotify(OrigenDatos oldWidget) =>
      esFirebase != oldWidget.esFirebase;
}

/// Pequeña etiqueta que indica de dónde vienen los datos que se ven:
/// "DEMO" (ficticios, en memoria) o "Firebase" (base de datos real).
///
/// Se coloca en el AppBar de las pantallas para que nunca haya dudas.
class EtiquetaOrigenDatos extends StatelessWidget {
  const EtiquetaOrigenDatos({super.key});

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final esFirebase = OrigenDatos.esFirebaseEn(context);

    return Tooltip(
      message: esFirebase
          ? 'Datos guardados en Cloud Firestore'
          : 'Datos ficticios en memoria: se pierden al cerrar la app',
      child: Chip(
        visualDensity: VisualDensity.compact,
        avatar: Icon(
          esFirebase ? Icons.cloud_done : Icons.science_outlined,
          size: 18,
          color: esFirebase ? colores.onPrimaryContainer : colores.onTertiaryContainer,
        ),
        label: Text(esFirebase ? 'Firebase' : 'DEMO'),
        labelStyle: TextStyle(
          fontWeight: FontWeight.bold,
          color: esFirebase ? colores.onPrimaryContainer : colores.onTertiaryContainer,
        ),
        backgroundColor:
            esFirebase ? colores.primaryContainer : colores.tertiaryContainer,
        side: BorderSide.none,
      ),
    );
  }
}
