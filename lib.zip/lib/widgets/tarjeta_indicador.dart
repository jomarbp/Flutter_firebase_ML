import 'package:flutter/material.dart';

/// Tarjeta para mostrar un indicador del negocio (KPI).
///
/// Recibe el valor YA calculado y formateado como texto: la tarjeta
/// solo lo muestra, nunca calcula ni inventa números.
class TarjetaIndicador extends StatelessWidget {
  const TarjetaIndicador({
    super.key,
    required this.icono,
    required this.titulo,
    required this.valor,
    this.detalle,
    this.color,
    this.alTocar,
  });

  final IconData icono;
  final String titulo;

  /// Valor principal, por ejemplo "S/ 1,250.00" o "12".
  final String valor;

  /// Texto pequeño opcional debajo del valor, por ejemplo "últimos 30 días".
  final String? detalle;

  /// Color del icono. Si es null se usa el color primario del tema.
  final Color? color;

  /// Acción opcional al tocar la tarjeta.
  final VoidCallback? alTocar;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;
    final colorIcono = color ?? colores.primary;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: alTocar,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Icon(icono, color: colorIcono),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      titulo,
                      style: textos.labelLarge?.copyWith(
                        color: colores.onSurfaceVariant,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // FittedBox reduce el texto si el número es muy largo,
              // así no se desborda en pantallas pequeñas.
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  valor,
                  style: textos.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              if (detalle != null) ...[
                const SizedBox(height: 4),
                Text(
                  detalle!,
                  style: textos.bodySmall?.copyWith(
                    color: colores.onSurfaceVariant,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
