import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:smartventas/models/detalle_venta.dart';
import 'package:smartventas/models/producto.dart';
import 'package:smartventas/models/venta.dart';
import 'package:smartventas/services/excepciones.dart';

/// CONTRATO (interfaz) del servicio de ventas.
///
/// Implementaciones:
///   • MemoriaVentaService   → modo DEMO (lib/services/memoria_service.dart)
///   • FirestoreVentaService → Cloud Firestore con transacciones (más abajo)
abstract class VentaService {
  /// Registra una venta y descuenta el stock EN UNA SOLA OPERACIÓN:
  /// o se guarda todo, o no se guarda nada.
  ///
  /// - [ventaId]: llave de idempotencia (ver Carrito.ventaId). Si ya existe
  ///   una venta con ese id, NO se registra otra: se devuelve la existente.
  /// - [cantidades]: id de producto → unidades.
  ///
  /// El precio, el nombre y el costo se toman del producto EN ESE MOMENTO
  /// (no de lo que envía la pantalla) y se copian en cada DetalleVenta.
  ///
  /// Lanza CarritoVacioException, ProductoNoEncontradoException,
  /// ProductoInactivoException, StockInsuficienteException o
  /// DatosInvalidosException si algo no es válido.
  Future<Venta> registrarVenta({
    required String ventaId,
    required Map<String, int> cantidades,
    String? vendedorUid,
  });

  /// Todas las ventas, de la más reciente a la más antigua. Se actualiza
  /// sola cuando se registra o anula una venta.
  Stream<List<Venta>> observarVentas();

  Future<Venta?> obtenerVenta(String id);

  /// Anula una venta confirmada y DEVUELVE el stock.
  /// Si ya estaba anulada, no hace nada (el stock no se devuelve dos veces).
  Future<Venta> anularVenta(String ventaId);
}

/// Ventas en Cloud Firestore, con TRANSACCIONES.
///
/// Una transacción de Firestore:
///   1. Lee los documentos (venta, contador, productos).
///   2. Ejecuta nuestro código con esos valores.
///   3. Escribe todo junto. Si otro usuario cambió alguno de los documentos
///      leídos mientras tanto, Firestore DESCARTA el intento y vuelve a
///      ejecutar el código con los valores nuevos (hasta 5 veces).
/// Así dos vendedores nunca pueden vender la misma última unidad.
///
/// Regla de Firestore: dentro de una transacción, TODAS las lecturas van
/// antes que cualquier escritura.
class FirestoreVentaService implements VentaService {
  FirestoreVentaService({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _ventas =>
      _db.collection('ventas');
  CollectionReference<Map<String, dynamic>> get _productos =>
      _db.collection('productos');
  DocumentReference<Map<String, dynamic>> get _contador =>
      _db.collection('contadores').doc('ventas');

  @override
  Future<Venta> registrarVenta({
    required String ventaId,
    required Map<String, int> cantidades,
    String? vendedorUid,
  }) {
    if (cantidades.isEmpty) throw const CarritoVacioException();

    return _db.runTransaction((transaccion) async {
      // ───── 1) LECTURAS ─────
      final ventaRef = _ventas.doc(ventaId);
      final ventaExistente = await transaccion.get(ventaRef);
      // Idempotencia: doble toque o reintento → misma venta, sin descontar.
      if (ventaExistente.exists) {
        return Venta.fromMap(ventaExistente.id, ventaExistente.data()!);
      }

      final contador = await transaccion.get(_contador);

      final productosLeidos = <String, Producto>{};
      for (final productoId in cantidades.keys) {
        final documento = await transaccion.get(_productos.doc(productoId));
        if (!documento.exists) throw ProductoNoEncontradoException(productoId);
        productosLeidos[productoId] =
            Producto.fromMap(documento.id, documento.data()!);
      }

      // ───── 2) VALIDACIONES (con los valores recién leídos) ─────
      final detalles = <DetalleVenta>[];
      for (final MapEntry(key: productoId, value: cantidad)
          in cantidades.entries) {
        final producto = productosLeidos[productoId]!;
        if (!producto.activo) throw ProductoInactivoException(producto.nombre);
        if (cantidad <= 0) {
          throw DatosInvalidosException(
              ['La cantidad de "${producto.nombre}" debe ser mayor que cero']);
        }
        if (cantidad > producto.stock) {
          throw StockInsuficienteException(
            nombreProducto: producto.nombre,
            disponible: producto.stock,
            solicitado: cantidad,
          );
        }
        detalles.add(DetalleVenta.desdeProducto(producto, cantidad));
      }

      final ultimoNumero = (contador.data()?['ultimoNumero'] as num?)?.toInt() ?? 0;
      final venta = Venta(
        id: ventaId,
        numero: ultimoNumero + 1,
        fecha: DateTime.now(),
        detalles: detalles,
        vendedorUid: vendedorUid,
      );

      // ───── 3) ESCRITURAS (todas o ninguna) ─────
      for (final detalle in detalles) {
        final producto = productosLeidos[detalle.productoId]!;
        transaccion.update(_productos.doc(producto.id), {
          'stock': producto.stock - detalle.cantidad,
          'tieneVentas': true,
          // Las reglas comprueban que esta venta se crea en la misma
          // operación: un vendedor no puede bajar stock "porque sí".
          'ultimaVentaId': ventaId,
          'fechaActualizacion': FieldValue.serverTimestamp(),
        });
      }
      transaccion.set(_contador, {'ultimoNumero': venta.numero});
      transaccion.set(ventaRef, venta.toMap());

      return venta;
    });
  }

  @override
  Stream<List<Venta>> observarVentas() {
    return _ventas.orderBy('fecha', descending: true).snapshots().map(
          (consulta) => consulta.docs
              .map((d) => Venta.fromMap(d.id, d.data()))
              .toList(),
        );
  }

  @override
  Future<Venta?> obtenerVenta(String id) async {
    final documento = await _ventas.doc(id).get();
    return documento.exists
        ? Venta.fromMap(documento.id, documento.data()!)
        : null;
  }

  @override
  Future<Venta> anularVenta(String ventaId) {
    return _db.runTransaction((transaccion) async {
      // 1) Lecturas
      final ventaRef = _ventas.doc(ventaId);
      final documento = await transaccion.get(ventaRef);
      if (!documento.exists) throw VentaNoEncontradaException(ventaId);
      final venta = Venta.fromMap(documento.id, documento.data()!);

      // Ya anulada: no se devuelve el stock otra vez.
      if (!venta.estaConfirmada) return venta;

      final productos = <String, DocumentSnapshot<Map<String, dynamic>>>{};
      for (final detalle in venta.detalles) {
        productos[detalle.productoId] ??=
            await transaccion.get(_productos.doc(detalle.productoId));
      }

      // 2) Escrituras
      final devolver = <String, int>{};
      for (final detalle in venta.detalles) {
        devolver[detalle.productoId] =
            (devolver[detalle.productoId] ?? 0) + detalle.cantidad;
      }
      for (final MapEntry(key: productoId, value: unidades) in devolver.entries) {
        final producto = productos[productoId]!;
        if (!producto.exists) continue; // eliminado: nada que devolver
        final stockActual = (producto.data()!['stock'] as num).toInt();
        transaccion.update(producto.reference, {
          'stock': stockActual + unidades,
          'fechaActualizacion': FieldValue.serverTimestamp(),
        });
      }

      final anulada = venta.copyWith(
        estado: EstadoVenta.anulada,
        fechaAnulacion: DateTime.now(),
      );
      transaccion.update(ventaRef, {
        'estado': anulada.estado.name,
        'fechaAnulacion': anulada.fechaAnulacion,
      });
      return anulada;
    });
  }
}
