import 'package:flutter/material.dart';

/// Muestra un icono grande y un mensaje cuando no hay datos que presentar.
///
/// Ejemplo: EstadoVacio(icono: Icons.inventory_2, titulo: 'Sin productos')
class EstadoVacio extends StatelessWidget {
  const EstadoVacio({
    super.key,
    required this.icono,
    required this.titulo,
    this.mensaje,
    this.accion,
  });

  final IconData icono;
  final String titulo;

  /// Texto secundario opcional, por ejemplo una sugerencia.
  final String? mensaje;

  /// Botón opcional, por ejemplo "Agregar producto".
  final Widget? accion;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icono, size: 72, color: colores.outline),
            const SizedBox(height: 16),
            Text(
              titulo,
              style: textos.titleLarge,
              textAlign: TextAlign.center,
            ),
            if (mensaje != null) ...[
              const SizedBox(height: 8),
              Text(
                mensaje!,
                style: textos.bodyMedium?.copyWith(
                  color: colores.onSurfaceVariant,
                ),
                textAlign: TextAlign.center,
              ),
            ],
            if (accion != null) ...[
              const SizedBox(height: 24),
              accion!,
            ],
          ],
        ),
      ),
    );
  }
}
