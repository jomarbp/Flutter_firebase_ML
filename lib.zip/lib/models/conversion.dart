/// Funciones de ayuda para convertir los valores que llegan de Firestore
/// o de un archivo JSON a tipos de Dart.
///
/// Firestore devuelve las fechas como `Timestamp` y los números a veces
/// como `int` y otras como `double`. Estas funciones aceptan todos los
/// casos para que los modelos no fallen.
library;

/// Convierte un valor a [DateTime].
///
/// Acepta: DateTime, texto ISO 8601 ("2026-10-28T10:15:00Z"),
/// milisegundos (int) o un Timestamp de Firestore (tiene el método toDate()).
DateTime fechaDesdeValor(Object? valor) {
  if (valor is DateTime) return valor;
  if (valor is String) return DateTime.parse(valor).toLocal();
  if (valor is int) return DateTime.fromMillisecondsSinceEpoch(valor);
  if (valor != null) {
    try {
      // Timestamp de Firestore. Se usa "dynamic" para que los modelos
      // no dependan del paquete cloud_firestore.
      return (valor as dynamic).toDate() as DateTime;
    } catch (_) {
      // Si no tiene toDate(), se lanza el error de abajo.
    }
  }
  throw FormatException('Fecha no válida: $valor');
}

/// Igual que [fechaDesdeValor], pero devuelve null si el valor es null.
DateTime? fechaOpcionalDesdeValor(Object? valor) =>
    valor == null ? null : fechaDesdeValor(valor);

/// Convierte un valor a entero. Si no es posible, devuelve [porDefecto].
int enteroDesdeValor(Object? valor, {int porDefecto = 0}) {
  if (valor is int) return valor;
  if (valor is num) return valor.round();
  if (valor is String) return int.tryParse(valor) ?? porDefecto;
  return porDefecto;
}
