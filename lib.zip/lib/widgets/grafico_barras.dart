import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

/// Un dato para los gráficos: una etiqueta (eje X) y uno o dos valores.
/// [valor2] se usa para comparar dos series (por ejemplo, dos períodos).
class DatoGrafico {
  const DatoGrafico(this.etiqueta, this.valor, {this.valor2, this.detalle});

  final String etiqueta;
  final double valor;
  final double? valor2;

  /// Texto extra para el tooltip (por ejemplo, la fecha completa).
  final String? detalle;
}

/// Colores de las series. Siempre en el MISMO orden (serie 1 azul, serie 2
/// naranja) y con un tono propio para el modo oscuro. Paleta validada para
/// personas con daltonismo.
class ColoresGrafico {
  ColoresGrafico._();

  static const _claro = [Color(0xFF2A78D6), Color(0xFFEB6834)];
  static const _oscuro = [Color(0xFF3987E5), Color(0xFFD95926)];

  static Color serie(BuildContext context, int indice) {
    final oscuro = Theme.of(context).brightness == Brightness.dark;
    return (oscuro ? _oscuro : _claro)[indice];
  }
}

/// Leyenda: un cuadrito de color + el nombre de cada serie.
class LeyendaGrafico extends StatelessWidget {
  const LeyendaGrafico({super.key, required this.nombres});

  final List<String> nombres;

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme.bodySmall;
    return Wrap(
      spacing: 16,
      runSpacing: 4,
      children: [
        for (var i = 0; i < nombres.length; i++)
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: ColoresGrafico.serie(context, i),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              const SizedBox(width: 6),
              Text(nombres[i], style: estilo),
            ],
          ),
      ],
    );
  }
}

/// Gráfico de barras VERTICALES (fl_chart). Con [DatoGrafico.valor2] dibuja
/// dos barras por grupo y muestra la leyenda.
///
/// Todas las barras comparten UN solo eje Y: nunca se mezclan unidades
/// distintas (soles y unidades) en el mismo gráfico.
class GraficoBarras extends StatelessWidget {
  const GraficoBarras({
    super.key,
    required this.datos,
    required this.formatearValor,
    this.formatearEje,
    this.nombresSeries = const [],
    this.etiquetaCada = 1,
    this.alto = 220,
  });

  final List<DatoGrafico> datos;

  /// Texto del valor en el tooltip, por ejemplo "S/ 249.70".
  final String Function(double valor) formatearValor;

  /// Texto corto para el eje Y. Si es null, se usa [formatearValor].
  final String Function(double valor)? formatearEje;

  /// Nombres de las series para la leyenda y el tooltip (solo si hay 2).
  final List<String> nombresSeries;

  /// Muestra una etiqueta del eje X cada N barras (evita que se encimen).
  final int etiquetaCada;
  final double alto;

  bool get _dosSeries => datos.any((d) => d.valor2 != null);

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final estiloEje = Theme.of(context)
        .textTheme
        .labelSmall
        ?.copyWith(color: colores.onSurfaceVariant);

    if (datos.isEmpty) {
      return SizedBox(height: alto, child: const Center(child: Text('Sin datos')));
    }

    final mayor = datos.fold<double>(
        0, (m, d) => math.max(m, math.max(d.valor, d.valor2 ?? 0)));
    final maxY = mayor <= 0 ? 1.0 : mayor * 1.15;
    final intervalo = maxY / 4;
    final ejeY = formatearEje ?? formatearValor;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_dosSeries && nombresSeries.length >= 2) ...[
          LeyendaGrafico(nombres: nombresSeries.take(2).toList()),
          const SizedBox(height: 12),
        ],
        SizedBox(
          height: alto,
          child: LayoutBuilder(builder: (context, restricciones) {
            // Ancho de cada barra según el espacio y la cantidad de barras.
            final series = _dosSeries ? 2 : 1;
            final espacio = (restricciones.maxWidth - 56) / datos.length;
            final ancho = (espacio * 0.6 / series).clamp(3.0, 22.0);

            BarChartRodData barra(double valor, Color color) => BarChartRodData(
                  toY: valor,
                  color: color,
                  width: ancho,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                );

            return BarChart(
              BarChartData(
                maxY: maxY,
                minY: 0,
                alignment: BarChartAlignment.spaceAround,
                borderData: FlBorderData(show: false),
                gridData: FlGridData(
                  drawVerticalLine: false,
                  horizontalInterval: intervalo,
                  getDrawingHorizontalLine: (_) =>
                      FlLine(color: colores.outlineVariant, strokeWidth: 1),
                ),
                titlesData: FlTitlesData(
                  topTitles: const AxisTitles(),
                  rightTitles: const AxisTitles(),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 52,
                      interval: intervalo,
                      getTitlesWidget: (valor, meta) => SideTitleWidget(
                        meta: meta,
                        child: Text(ejeY(valor), style: estiloEje),
                      ),
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28,
                      getTitlesWidget: (valor, meta) {
                        final i = valor.toInt();
                        if (i < 0 || i >= datos.length || i % etiquetaCada != 0) {
                          return const SizedBox.shrink();
                        }
                        return SideTitleWidget(
                          meta: meta,
                          child: Text(datos[i].etiqueta, style: estiloEje),
                        );
                      },
                    ),
                  ),
                ),
                barTouchData: BarTouchData(
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipColor: (_) => colores.inverseSurface,
                    getTooltipItem: (grupo, indiceGrupo, barra, indiceBarra) {
                      final dato = datos[indiceGrupo];
                      final serie = _dosSeries && nombresSeries.length > indiceBarra
                          ? '${nombresSeries[indiceBarra]}: '
                          : '';
                      return BarTooltipItem(
                        '${dato.detalle ?? dato.etiqueta}\n'
                        '$serie${formatearValor(barra.toY)}',
                        TextStyle(color: colores.onInverseSurface, fontSize: 12),
                      );
                    },
                  ),
                ),
                barGroups: [
                  for (var i = 0; i < datos.length; i++)
                    BarChartGroupData(
                      x: i,
                      barsSpace: 2,
                      barRods: [
                        barra(datos[i].valor, ColoresGrafico.serie(context, 0)),
                        if (datos[i].valor2 != null)
                          barra(datos[i].valor2!, ColoresGrafico.serie(context, 1)),
                      ],
                    ),
                ],
              ),
            );
          }),
        ),
      ],
    );
  }
}

/// Barras HORIZONTALES hechas con widgets comunes. Son ideales para
/// rankings: los nombres largos de productos se leen completos.
class BarrasHorizontales extends StatelessWidget {
  const BarrasHorizontales({
    super.key,
    required this.datos,
    required this.formatearValor,
    this.maximoVisible,
  });

  final List<DatoGrafico> datos;
  final String Function(double valor) formatearValor;

  /// Muestra solo los primeros N (null = todos).
  final int? maximoVisible;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;
    final visibles =
        maximoVisible == null ? datos : datos.take(maximoVisible!).toList();
    if (visibles.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Text('Sin datos en este período'),
      );
    }
    final mayor = visibles.fold<double>(0, (m, d) => math.max(m, d.valor));

    return Column(
      children: [
        for (final (indice, dato) in visibles.indexed)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text('${indice + 1}. ',
                        style: textos.bodySmall
                            ?.copyWith(color: colores.onSurfaceVariant)),
                    Expanded(
                      child: Text(dato.etiqueta,
                          style: textos.bodyMedium,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      dato.detalle == null
                          ? formatearValor(dato.valor)
                          : '${formatearValor(dato.valor)} · ${dato.detalle}',
                      style: textos.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: mayor == 0 ? 0 : dato.valor / mayor,
                    minHeight: 8,
                    color: ColoresGrafico.serie(context, 0),
                    backgroundColor: colores.surfaceContainerHighest,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
