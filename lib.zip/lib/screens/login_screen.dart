import 'package:flutter/material.dart';

import 'package:smartventas/config.dart';
import 'package:smartventas/services/auth_service.dart';
import 'package:smartventas/services/excepciones.dart';

/// Inicio de sesión con correo y contraseña (solo en modo Firebase).
///
/// No navega por sí misma: cuando el inicio de sesión tiene éxito,
/// AuthService.observarSesion() emite el usuario y app.dart muestra
/// automáticamente la pantalla principal.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.authService});

  final AuthService authService;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _correo = TextEditingController();
  final _contrasena = TextEditingController();
  bool _ocultar = true;
  bool _cargando = false;
  String? _error;

  @override
  void dispose() {
    _correo.dispose();
    _contrasena.dispose();
    super.dispose();
  }

  Future<void> _ingresar() async {
    if (_cargando) return;
    if (!(_formKey.currentState?.validate() ?? false)) return;

    setState(() {
      _cargando = true;
      _error = null;
    });
    try {
      await widget.authService.iniciarSesion(_correo.text, _contrasena.text);
    } on SmartVentasException catch (error) {
      if (mounted) setState(() => _error = error.mensaje);
    } catch (error) {
      if (mounted) setState(() => _error = 'No se pudo iniciar sesión: $error');
    } finally {
      if (mounted) setState(() => _cargando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;

    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            // En pantallas anchas (Chrome) el formulario no se estira.
            constraints: const BoxConstraints(maxWidth: 420),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(Icons.storefront, size: 72, color: colores.primary),
                  const SizedBox(height: 12),
                  Text(AppConfig.nombreApp,
                      textAlign: TextAlign.center, style: textos.headlineMedium),
                  Text(AppConfig.nombreTienda,
                      textAlign: TextAlign.center, style: textos.titleSmall),
                  const SizedBox(height: 32),
                  TextFormField(
                    controller: _correo,
                    decoration: const InputDecoration(
                      labelText: 'Correo',
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                    keyboardType: TextInputType.emailAddress,
                    autofillHints: const [AutofillHints.email],
                    textInputAction: TextInputAction.next,
                    validator: (valor) {
                      final texto = valor?.trim() ?? '';
                      if (texto.isEmpty) return 'Ingresa tu correo';
                      if (!texto.contains('@') || !texto.contains('.')) {
                        return 'Correo no válido';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _contrasena,
                    obscureText: _ocultar,
                    decoration: InputDecoration(
                      labelText: 'Contraseña',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                        tooltip: _ocultar ? 'Mostrar' : 'Ocultar',
                        icon: Icon(_ocultar
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined),
                        onPressed: () => setState(() => _ocultar = !_ocultar),
                      ),
                    ),
                    autofillHints: const [AutofillHints.password],
                    textInputAction: TextInputAction.done,
                    onFieldSubmitted: (_) => _ingresar(),
                    validator: (valor) =>
                        (valor ?? '').isEmpty ? 'Ingresa tu contraseña' : null,
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 16),
                    Text(_error!,
                        textAlign: TextAlign.center,
                        style: TextStyle(color: colores.error)),
                  ],
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: _cargando ? null : _ingresar,
                    child: _cargando
                        ? const SizedBox.square(
                            dimension: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Ingresar'),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Las cuentas las crea el administrador de la tienda.',
                    textAlign: TextAlign.center,
                    style: textos.bodySmall,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
