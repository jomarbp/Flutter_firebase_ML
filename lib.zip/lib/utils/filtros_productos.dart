/// Búsqueda, filtro y orden de la lista de productos.
///
/// Es una función pura (no usa Flutter ni Firebase): recibe una lista y
/// devuelve otra. Por eso se puede probar fácilmente con `flutter test`.
library;

import 'package:smartventas/models/producto.dart';
import 'package:smartventas/utils/formato.dart';

/// Formas de ordenar la lista. Cada opción trae el texto para el menú.
enum OrdenProducto {
  nombre('Nombre (A-Z)'),
  precioAscendente('Precio: menor a mayor'),
  precioDescendente('Precio: mayor a menor'),
  stockAscendente('Stock: menor a mayor'),
  stockDescendente('Stock: mayor a menor');

  const OrdenProducto(this.etiqueta);
  final String etiqueta;
}

/// Devuelve una NUEVA lista con los productos que cumplen los filtros,
/// en el orden pedido. La lista original no se modifica.
///
/// - [texto]: busca dentro del nombre, sin importar mayúsculas ni tildes.
/// - [categoria]: null = todas las categorías.
/// - [incluirInactivos]: false = oculta los productos desactivados.
List<Producto> filtrarProductos(
  List<Producto> productos, {
  String texto = '',
  String? categoria,
  OrdenProducto orden = OrdenProducto.nombre,
  bool incluirInactivos = false,
}) {
  final busqueda = normalizarTexto(texto.trim());

  final resultado = productos.where((producto) {
    if (!incluirInactivos && !producto.activo) return false;
    if (categoria != null && producto.categoria != categoria) return false;
    if (busqueda.isNotEmpty &&
        !normalizarTexto(producto.nombre).contains(busqueda)) {
      return false;
    }
    return true;
  }).toList();

  int porNombre(Producto a, Producto b) =>
      normalizarTexto(a.nombre).compareTo(normalizarTexto(b.nombre));

  resultado.sort((a, b) {
    final comparacion = switch (orden) {
      OrdenProducto.nombre => 0,
      OrdenProducto.precioAscendente =>
        a.precioCentimos.compareTo(b.precioCentimos),
      OrdenProducto.precioDescendente =>
        b.precioCentimos.compareTo(a.precioCentimos),
      OrdenProducto.stockAscendente => a.stock.compareTo(b.stock),
      OrdenProducto.stockDescendente => b.stock.compareTo(a.stock),
    };
    // Si empatan (mismo precio o stock), se desempata por nombre.
    return comparacion != 0 ? comparacion : porNombre(a, b);
  });

  return resultado;
}
