import 'package:flutter/material.dart';

import 'package:smartventas/screens/dashboard_screen.dart';
import 'package:smartventas/screens/historial_ventas_screen.dart';
import 'package:smartventas/screens/nueva_venta_screen.dart';
import 'package:smartventas/screens/productos_screen.dart';
import 'package:smartventas/screens/reportes_screen.dart';
import 'package:smartventas/services/auth_service.dart';
import 'package:smartventas/services/servicios.dart';

/// Pantalla contenedora con la barra de navegación inferior.
///
/// Es un StatefulWidget porque debe recordar qué pestaña está activa.
class InicioScreen extends StatefulWidget {
  const InicioScreen({
    super.key,
    required this.servicios,
    required this.usuario,
  });

  final Servicios servicios;

  /// Usuario con sesión iniciada: su rol decide qué puede hacer.
  final Usuario usuario;

  @override
  State<InicioScreen> createState() => _InicioScreenState();
}

class _InicioScreenState extends State<InicioScreen> {
  /// Índice de la pestaña seleccionada (0 = Inicio).
  int _indiceActual = 0;

  /// Las cinco pantallas principales, en el mismo orden que los destinos.
  /// Se crean una sola vez para que cada una conserve su estado.
  late final List<Widget> _pantallas = [
    DashboardScreen(
      usuario: widget.usuario,
      authService: widget.servicios.auth,
      productoService: widget.servicios.productos,
      ventaService: widget.servicios.ventas,
    ),
    ProductosScreen(
      productoService: widget.servicios.productos,
      // Solo el administrador registra, edita o elimina productos.
      puedeEditar: widget.usuario.esAdmin,
    ),
    NuevaVentaScreen(
      productoService: widget.servicios.productos,
      ventaService: widget.servicios.ventas,
      vendedorUid: widget.usuario.uid,
    ),
    HistorialVentasScreen(
      ventaService: widget.servicios.ventas,
      // Solo el administrador puede anular ventas.
      puedeAnular: widget.usuario.esAdmin,
    ),
    ReportesScreen(
      ventaService: widget.servicios.ventas,
      productoService: widget.servicios.productos,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // IndexedStack mantiene vivas todas las pantallas: si el usuario
      // está armando un carrito y cambia de pestaña, no lo pierde.
      body: IndexedStack(
        index: _indiceActual,
        children: _pantallas,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _indiceActual,
        onDestinationSelected: (indice) {
          setState(() => _indiceActual = indice);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard),
            label: 'Inicio',
          ),
          NavigationDestination(
            icon: Icon(Icons.inventory_2_outlined),
            selectedIcon: Icon(Icons.inventory_2),
            label: 'Productos',
          ),
          NavigationDestination(
            icon: Icon(Icons.point_of_sale_outlined),
            selectedIcon: Icon(Icons.point_of_sale),
            label: 'Vender',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'Historial',
          ),
          NavigationDestination(
            icon: Icon(Icons.bar_chart_outlined),
            selectedIcon: Icon(Icons.bar_chart),
            label: 'Reportes',
          ),
        ],
      ),
    );
  }
}
