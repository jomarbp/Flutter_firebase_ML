/// Funciones para mostrar dinero, fechas y texto, y para leer importes
/// escritos por el usuario.
///
/// ESTRATEGIA PARA EL DINERO
/// Todos los importes se guardan como números ENTEROS de céntimos:
/// S/ 49.90 se guarda como 4990. Así las sumas y multiplicaciones son
/// exactas. Con double, 0.1 + 0.2 da 0.30000000000000004.
library;

import 'package:smartventas/config.dart';

// ─────────────────────────── DINERO ───────────────────────────

/// Convierte céntimos a texto con símbolo de moneda.
///
/// formatearSoles(4990)    → "S/ 49.90"
/// formatearSoles(123450)  → "S/ 1,234.50"
/// formatearSoles(-500)    → "-S/ 5.00"
String formatearSoles(int centimos) {
  final negativo = centimos < 0;
  final absoluto = centimos.abs();
  final soles = absoluto ~/ 100; // división entera
  final resto = absoluto % 100; // céntimos sobrantes
  final texto =
      '${AppConfig.simboloMoneda} ${_separarMiles(soles)}.${_dosDigitos(resto)}';
  return negativo ? '-$texto' : texto;
}

/// Convierte céntimos al texto que se escribe en un campo de formulario.
///
/// centimosATexto(4990) → "49.90"
String centimosATexto(int centimos) {
  final signo = centimos < 0 ? '-' : '';
  final absoluto = centimos.abs();
  return '$signo${absoluto ~/ 100}.${_dosDigitos(absoluto % 100)}';
}

/// Convierte el texto que escribió el usuario a céntimos.
///
/// Devuelve null si el texto no es un importe válido.
/// textoACentimos("49.9")   → 4990
/// textoACentimos("49,90")  → 4990  (la coma se acepta como decimal)
/// textoACentimos("15")     → 1500
/// textoACentimos("1.999")  → null  (más de 2 decimales)
/// textoACentimos("-5")     → null  (negativo)
/// textoACentimos("abc")    → null
///
/// IMPORTANTE: no se hace double.parse(texto) * 100, porque
/// 0.29 * 100 = 28.999999999999996. Se separan la parte entera y la
/// decimal como TEXTO y se combinan con enteros.
int? textoACentimos(String? texto) {
  if (texto == null) return null;
  var limpio = texto
      .trim()
      .replaceAll(AppConfig.simboloMoneda, '')
      .replaceAll(' ', '');
  if (limpio.isEmpty) return null;

  // Si no hay punto pero sí una coma, la coma es el separador decimal.
  if (!limpio.contains('.') && limpio.contains(',')) {
    limpio = limpio.replaceAll(',', '.');
  }

  // Uno o más dígitos, y opcionalmente un punto con 1 o 2 dígitos.
  final patron = RegExp(r'^(\d{1,9})(?:\.(\d{1,2}))?$');
  final coincidencia = patron.firstMatch(limpio);
  if (coincidencia == null) return null;

  final parteEntera = int.parse(coincidencia.group(1)!);
  final parteDecimal = coincidencia.group(2) ?? '';
  // "9" → "90" para que 49.9 sea 49 soles con 90 céntimos.
  final centimos =
      parteDecimal.isEmpty ? 0 : int.parse(parteDecimal.padRight(2, '0'));

  return parteEntera * 100 + centimos;
}

/// 1234567 → "1,234,567"
String _separarMiles(int numero) {
  final digitos = numero.toString();
  final resultado = StringBuffer();
  for (var i = 0; i < digitos.length; i++) {
    final faltan = digitos.length - i;
    if (i > 0 && faltan % 3 == 0) resultado.write(',');
    resultado.write(digitos[i]);
  }
  return resultado.toString();
}

String _dosDigitos(int numero) => numero.toString().padLeft(2, '0');

/// Importe en SOLES (double) con 2 decimales: 49.9 → "S/ 49.90".
/// Se usa para resultados estadísticos y gráficos. El redondeo se hace
/// aquí, al mostrar, pasando a céntimos enteros.
String formatearSolesDecimal(double soles) => formatearSoles((soles * 100).round());

/// Versión corta para los ejes de los gráficos: 450 → "S/ 450",
/// 1250 → "S/ 1.3 k".
String formatearSolesCorto(double soles) {
  if (soles.abs() >= 1000) {
    return '${AppConfig.simboloMoneda} ${(soles / 1000).toStringAsFixed(1)} k';
  }
  return '${AppConfig.simboloMoneda} ${soles.round()}';
}

/// Número con [decimales] decimales: 2.666 → "2.67".
String formatearDecimal(double valor, {int decimales = 2}) =>
    valor.toStringAsFixed(decimales);

/// Fecha corta para ejes: 07/03.
String formatearDiaMes(DateTime fecha) =>
    '${_dosDigitos(fecha.day)}/${_dosDigitos(fecha.month)}';

// ─────────────────────────── PORCENTAJES ───────────────────────────

/// formatearPorcentaje(37.456) → "37.5 %"
String formatearPorcentaje(double valor, {int decimales = 1}) =>
    '${valor.toStringAsFixed(decimales)} %';

// ─────────────────────────── FECHAS ───────────────────────────

/// 28/10/2026
String formatearFecha(DateTime fecha) =>
    '${_dosDigitos(fecha.day)}/${_dosDigitos(fecha.month)}/${fecha.year}';

/// 09:05
String formatearHora(DateTime fecha) =>
    '${_dosDigitos(fecha.hour)}:${_dosDigitos(fecha.minute)}';

/// 28/10/2026 09:05
String formatearFechaHora(DateTime fecha) =>
    '${formatearFecha(fecha)} ${formatearHora(fecha)}';

/// Devuelve solo el día (sin hora): útil para agrupar ventas por día.
DateTime soloFecha(DateTime fecha) =>
    DateTime(fecha.year, fecha.month, fecha.day);

// ─────────────────────────── TEXTO ───────────────────────────

/// Convierte a minúsculas y quita tildes para buscar sin importar cómo
/// se escribió: "Audífonos" y "audifonos" quedan iguales.
String normalizarTexto(String texto) {
  const conTilde = 'áàäâéèëêíìïîóòöôúùüûñ';
  const sinTilde = 'aaaaeeeeiiiioooouuuun';
  final resultado = StringBuffer();
  for (final letra in texto.toLowerCase().split('')) {
    final posicion = conTilde.indexOf(letra);
    resultado.write(posicion >= 0 ? sinTilde[posicion] : letra);
  }
  return resultado.toString();
}
