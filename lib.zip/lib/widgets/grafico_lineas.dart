import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import 'package:smartventas/widgets/grafico_barras.dart';

/// Gráfico de LÍNEAS (fl_chart) para ver la evolución en el tiempo,
/// por ejemplo los ingresos de cada día. Una sola serie y un solo eje Y.
class GraficoLineas extends StatelessWidget {
  const GraficoLineas({
    super.key,
    required this.datos,
    required this.formatearValor,
    this.formatearEje,
    this.etiquetaCada = 1,
    this.alto = 220,
  });

  final List<DatoGrafico> datos;
  final String Function(double valor) formatearValor;
  final String Function(double valor)? formatearEje;
  final int etiquetaCada;
  final double alto;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final color = ColoresGrafico.serie(context, 0);
    final estiloEje = Theme.of(context)
        .textTheme
        .labelSmall
        ?.copyWith(color: colores.onSurfaceVariant);

    if (datos.isEmpty) {
      return SizedBox(height: alto, child: const Center(child: Text('Sin datos')));
    }

    final mayor = datos.fold<double>(0, (m, d) => math.max(m, d.valor));
    final maxY = mayor <= 0 ? 1.0 : mayor * 1.15;
    final intervalo = maxY / 4;
    final ejeY = formatearEje ?? formatearValor;

    return SizedBox(
      height: alto,
      child: LineChart(
        LineChartData(
          minY: 0,
          maxY: maxY,
          minX: 0,
          maxX: (datos.length - 1).toDouble(),
          borderData: FlBorderData(show: false),
          gridData: FlGridData(
            drawVerticalLine: false,
            horizontalInterval: intervalo,
            getDrawingHorizontalLine: (_) =>
                FlLine(color: colores.outlineVariant, strokeWidth: 1),
          ),
          titlesData: FlTitlesData(
            topTitles: const AxisTitles(),
            rightTitles: const AxisTitles(),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 52,
                interval: intervalo,
                getTitlesWidget: (valor, meta) => SideTitleWidget(
                  meta: meta,
                  child: Text(ejeY(valor), style: estiloEje),
                ),
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 28,
                interval: 1,
                getTitlesWidget: (valor, meta) {
                  final i = valor.toInt();
                  if (valor != i.toDouble() ||
                      i < 0 ||
                      i >= datos.length ||
                      i % etiquetaCada != 0) {
                    return const SizedBox.shrink();
                  }
                  return SideTitleWidget(
                    meta: meta,
                    child: Text(datos[i].etiqueta, style: estiloEje),
                  );
                },
              ),
            ),
          ),
          lineTouchData: LineTouchData(
            touchTooltipData: LineTouchTooltipData(
              getTooltipColor: (_) => colores.inverseSurface,
              getTooltipItems: (puntos) => [
                for (final punto in puntos)
                  LineTooltipItem(
                    '${datos[punto.x.toInt()].detalle ?? datos[punto.x.toInt()].etiqueta}\n'
                    '${formatearValor(punto.y)}',
                    TextStyle(color: colores.onInverseSurface, fontSize: 12),
                  ),
              ],
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: [
                for (var i = 0; i < datos.length; i++)
                  FlSpot(i.toDouble(), datos[i].valor),
              ],
              color: color,
              barWidth: 2,
              // Puntos solo si son pocos días; con muchos, solo la línea.
              dotData: FlDotData(
                show: datos.length <= 31,
                getDotPainter: (punto, porcentaje, barra, indice) =>
                    FlDotCirclePainter(
                  radius: 3,
                  color: color,
                  strokeWidth: 2,
                  strokeColor: colores.surface,
                ),
              ),
              belowBarData: BarAreaData(
                show: true,
                color: color.withValues(alpha: 0.12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
