/// Reglas de validación de SmartVentas.
///
/// Los validadores de formulario devuelven:
///   • null      → el valor es correcto
///   • un texto  → el mensaje de error que verá el usuario
/// Es el formato que espera `TextFormField(validator: ...)`.
library;

import 'package:smartventas/models/producto.dart';
import 'package:smartventas/utils/formato.dart';

/// Precio máximo aceptado: S/ 100,000.00 (evita errores de tipeo).
const int precioMaximoCentimos = 10000000;

/// Cantidad máxima de stock o de unidades en una línea de venta.
const int cantidadMaxima = 100000;

// ─────────────────────────── FORMULARIO DE PRODUCTO ───────────────────────────

String? validarNombreProducto(String? valor) {
  final texto = valor?.trim() ?? '';
  if (texto.isEmpty) return 'Ingresa el nombre del producto';
  if (texto.length < 3) return 'El nombre debe tener al menos 3 caracteres';
  if (texto.length > 60) return 'El nombre no puede superar 60 caracteres';
  return null;
}

String? validarCategoria(String? valor) {
  if (valor == null || !categoriasProducto.contains(valor)) {
    return 'Selecciona una categoría';
  }
  return null;
}

/// El precio de venta debe ser MAYOR que cero.
String? validarPrecioVenta(String? valor) {
  return _validarImporte(valor, nombreCampo: 'el precio', permitirCero: false);
}

/// El costo puede ser cero (por ejemplo, un regalo de un proveedor),
/// pero nunca negativo.
String? validarCostoUnitario(String? valor) {
  return _validarImporte(valor, nombreCampo: 'el costo', permitirCero: true);
}

String? _validarImporte(
  String? valor, {
  required String nombreCampo,
  required bool permitirCero,
}) {
  final texto = valor?.trim() ?? '';
  if (texto.isEmpty) return 'Ingresa $nombreCampo';
  if (texto.startsWith('-')) return 'No se permiten importes negativos';

  final centimos = textoACentimos(texto);
  if (centimos == null) {
    return 'Usa un número con hasta 2 decimales, por ejemplo 49.90';
  }
  if (!permitirCero && centimos == 0) {
    return 'Debe ser mayor que ${formatearSoles(0)}';
  }
  if (centimos > precioMaximoCentimos) {
    return 'No puede superar ${formatearSoles(precioMaximoCentimos)}';
  }
  return null;
}

/// Para stock y stock mínimo: enteros, sin decimales, desde 0.
String? validarEnteroNoNegativo(String? valor, {required String nombreCampo}) {
  final texto = valor?.trim() ?? '';
  if (texto.isEmpty) return 'Ingresa $nombreCampo';
  if (texto.startsWith('-')) return 'No se permiten cantidades negativas';

  final numero = int.tryParse(texto);
  if (numero == null) return 'Debe ser un número entero, sin decimales';
  if (numero > cantidadMaxima) return 'No puede superar $cantidadMaxima';
  return null;
}

// ─────────────────────────── VALIDACIÓN COMPLETA ───────────────────────────

/// Valida un producto completo y devuelve la lista de errores.
///
/// La usan los SERVICIOS antes de guardar: aunque la pantalla ya validó,
/// el servicio vuelve a revisar (nunca se confía solo en la interfaz).
List<String> validarProducto(Producto producto) {
  final errores = <String>[];

  final errorNombre = validarNombreProducto(producto.nombre);
  if (errorNombre != null) errores.add(errorNombre);

  final errorCategoria = validarCategoria(producto.categoria);
  if (errorCategoria != null) errores.add(errorCategoria);

  if (producto.precioCentimos <= 0) {
    errores.add('El precio debe ser mayor que cero');
  } else if (producto.precioCentimos > precioMaximoCentimos) {
    errores.add('El precio supera el máximo permitido');
  }

  if (producto.costoCentimos < 0) {
    errores.add('El costo no puede ser negativo');
  } else if (producto.costoCentimos > precioMaximoCentimos) {
    errores.add('El costo supera el máximo permitido');
  }

  if (producto.stock < 0 || producto.stock > cantidadMaxima) {
    errores.add('El stock debe estar entre 0 y $cantidadMaxima');
  }
  if (producto.stockMinimo < 0 || producto.stockMinimo > cantidadMaxima) {
    errores.add('El stock mínimo debe estar entre 0 y $cantidadMaxima');
  }

  return errores;
}

// ─────────────────────────── VENTAS ───────────────────────────

/// Valida la cantidad de una línea de venta contra el stock disponible.
String? validarCantidadVenta(int cantidad, int stockDisponible) {
  if (cantidad <= 0) return 'La cantidad debe ser mayor que cero';
  if (cantidad > stockDisponible) {
    return stockDisponible == 0
        ? 'Producto agotado'
        : 'Stock insuficiente: solo hay $stockDisponible unidades';
  }
  return null;
}
