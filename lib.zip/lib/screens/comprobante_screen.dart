import 'package:flutter/material.dart';

import 'package:smartventas/config.dart';
import 'package:smartventas/models/venta.dart';
import 'package:smartventas/utils/formato.dart';

/// Comprobante sencillo que se muestra después de confirmar una venta.
class ComprobanteScreen extends StatelessWidget {
  const ComprobanteScreen({super.key, required this.venta});

  final Venta venta;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Comprobante')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TarjetaComprobante(venta: venta),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.add_shopping_cart),
            label: const Text('Nueva venta'),
          ),
        ],
      ),
    );
  }
}

/// Tarjeta con los datos de una venta. Es pública porque también la usa la
/// pantalla de detalle del historial (Fase 6).
class TarjetaComprobante extends StatelessWidget {
  const TarjetaComprobante({super.key, required this.venta});

  final Venta venta;

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    final textos = Theme.of(context).textTheme;
    final anulada = !venta.estaConfirmada;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Icon(
              anulada ? Icons.cancel_outlined : Icons.check_circle_outline,
              size: 48,
              color: anulada ? colores.error : colores.primary,
            ),
            const SizedBox(height: 8),
            Text(
              anulada ? 'Venta ANULADA' : 'Venta registrada',
              textAlign: TextAlign.center,
              style: textos.titleMedium?.copyWith(
                color: anulada ? colores.error : null,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              venta.codigo,
              textAlign: TextAlign.center,
              style: textos.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            Text(
              '${AppConfig.nombreTienda} · ${formatearFechaHora(venta.fecha)}',
              textAlign: TextAlign.center,
              style: textos.bodySmall,
            ),
            if (anulada && venta.fechaAnulacion != null)
              Text(
                'Anulada el ${formatearFechaHora(venta.fechaAnulacion!)}',
                textAlign: TextAlign.center,
                style: textos.bodySmall?.copyWith(color: colores.error),
              ),
            const Divider(height: 32),
            for (final detalle in venta.detalles)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(detalle.nombreProducto, style: textos.bodyLarge),
                          Text(
                            '${detalle.cantidad} × '
                            '${formatearSoles(detalle.precioUnitarioCentimos)}',
                            style: textos.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    Text(formatearSoles(detalle.subtotalCentimos),
                        style: textos.bodyLarge),
                  ],
                ),
              ),
            const Divider(height: 32),
            Row(
              children: [
                Expanded(
                  child: Text('TOTAL (${venta.unidadesTotales} unidades)',
                      style: textos.titleMedium),
                ),
                Text(
                  formatearSoles(venta.totalCentimos),
                  style: textos.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    decoration: anulada ? TextDecoration.lineThrough : null,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              'Comprobante interno de ${AppConfig.nombreApp}. '
              'No reemplaza a una boleta o factura electrónica.',
              textAlign: TextAlign.center,
              style: textos.labelSmall?.copyWith(color: colores.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}
