/// Errores de negocio de SmartVentas.
///
/// Los servicios lanzan estas excepciones con mensajes claros en español
/// y las pantallas las capturan para mostrarlas en un SnackBar.
library;

/// Clase base: todas las excepciones de la app tienen un [mensaje].
class SmartVentasException implements Exception {
  const SmartVentasException(this.mensaje);

  final String mensaje;

  @override
  String toString() => mensaje;
}

/// Los datos no cumplen las validaciones (ver utils/validaciones.dart).
class DatosInvalidosException extends SmartVentasException {
  DatosInvalidosException(this.errores) : super(errores.join('\n'));

  final List<String> errores;
}

/// Ya existe otro producto con el mismo nombre.
class ProductoDuplicadoException extends SmartVentasException {
  const ProductoDuplicadoException(String nombre)
      : super('Ya existe un producto llamado "$nombre"');
}

class ProductoNoEncontradoException extends SmartVentasException {
  const ProductoNoEncontradoException(String id)
      : super('El producto ($id) no existe o fue eliminado');
}

/// Se intentó vender un producto desactivado.
class ProductoInactivoException extends SmartVentasException {
  const ProductoInactivoException(String nombre)
      : super('"$nombre" está desactivado y no se puede vender');
}

/// Se intentó vender más unidades de las disponibles.
class StockInsuficienteException extends SmartVentasException {
  const StockInsuficienteException({
    required this.nombreProducto,
    required this.disponible,
    required this.solicitado,
  }) : super('Stock insuficiente de "$nombreProducto": '
            'se pidieron $solicitado y solo hay $disponible');

  final String nombreProducto;
  final int disponible;
  final int solicitado;
}

class CarritoVacioException extends SmartVentasException {
  const CarritoVacioException()
      : super('Agrega al menos un producto antes de confirmar la venta');
}

class VentaNoEncontradaException extends SmartVentasException {
  const VentaNoEncontradaException(String id)
      : super('La venta ($id) no existe');
}

/// El usuario no tiene el rol necesario (por ejemplo, un vendedor que
/// intenta anular una venta).
class PermisoDenegadoException extends SmartVentasException {
  const PermisoDenegadoException([
    super.mensaje = 'No tienes permiso para realizar esta acción',
  ]);
}
