/// Cálculos de los indicadores y reportes comerciales.
///
/// Son FUNCIONES PURAS: reciben listas de ventas o productos y devuelven
/// resultados, sin usar Flutter ni Firebase. Por eso se prueban fácilmente
/// y los números del Dashboard y de los Reportes salen SIEMPRE de los datos,
/// nunca de valores escritos a mano en los widgets.
///
/// Regla general: solo cuentan las ventas CONFIRMADAS. Las anuladas se
/// muestran en el historial, pero no suman ingresos ni unidades.
///
/// CONCEPTOS (no confundirlos):
///   • Ingresos por ventas       = suma de los totales cobrados.
///   • Costo estimado            = suma de (costo unitario guardado × cantidad).
///   • Margen bruto estimado     = ingresos − costo estimado.
///   • Ganancia neta             = NO se calcula: faltan alquiler, sueldos,
///                                  impuestos, servicios y otros gastos.
library;

import 'package:smartventas/models/producto.dart';
import 'package:smartventas/models/venta.dart';
import 'package:smartventas/utils/formato.dart';

// ─────────────────────────── Filtros de ventas ───────────────────────────

/// Solo las ventas confirmadas.
List<Venta> ventasConfirmadas(Iterable<Venta> ventas) =>
    ventas.where((v) => v.estaConfirmada).toList();

/// Ventas cuya fecha está entre [desde] y [hasta], AMBOS DÍAS INCLUIDOS.
/// Si alguno es null, ese extremo no se limita.
List<Venta> ventasEnRango(Iterable<Venta> ventas, {DateTime? desde, DateTime? hasta}) {
  final inicio = desde == null ? null : soloFecha(desde);
  // "hasta" incluye todo ese día: se compara con el inicio del día siguiente.
  final finExclusivo = hasta == null
      ? null
      : soloFecha(hasta).add(const Duration(days: 1));
  return ventas.where((v) {
    if (inicio != null && v.fecha.isBefore(inicio)) return false;
    if (finExclusivo != null && !v.fecha.isBefore(finExclusivo)) return false;
    return true;
  }).toList();
}

/// Búsqueda del historial: por número de venta y por rango de fechas.
///
/// [texto] acepta "41", "000041" o "V-000041".
List<Venta> filtrarVentas(
  Iterable<Venta> ventas, {
  String texto = '',
  DateTime? desde,
  DateTime? hasta,
}) {
  final digitos = texto.replaceAll(RegExp(r'[^0-9]'), '');
  final numeroBuscado = digitos.isEmpty ? null : int.parse(digitos);
  final enRango = ventasEnRango(ventas, desde: desde, hasta: hasta);
  final resultado = numeroBuscado == null
      ? enRango
      : enRango.where((v) => v.numero == numeroBuscado).toList();
  resultado.sort((a, b) => b.fecha.compareTo(a.fecha));
  return resultado;
}

// ─────────────────────────── Resumen ───────────────────────────

/// Totales de un conjunto de ventas (solo se cuentan las confirmadas).
class ResumenVentas {
  const ResumenVentas({
    required this.numeroVentas,
    required this.unidades,
    required this.ingresosCentimos,
    required this.costoCentimos,
  });

  factory ResumenVentas.de(Iterable<Venta> ventas) {
    final confirmadas = ventasConfirmadas(ventas);
    return ResumenVentas(
      numeroVentas: confirmadas.length,
      unidades: confirmadas.fold(0, (s, v) => s + v.unidadesTotales),
      ingresosCentimos: confirmadas.fold(0, (s, v) => s + v.totalCentimos),
      costoCentimos: confirmadas.fold(0, (s, v) => s + v.costoTotalCentimos),
    );
  }

  static const vacio = ResumenVentas(
      numeroVentas: 0, unidades: 0, ingresosCentimos: 0, costoCentimos: 0);

  final int numeroVentas;
  final int unidades;
  final int ingresosCentimos;
  final int costoCentimos;

  int get margenBrutoCentimos => ingresosCentimos - costoCentimos;

  /// Margen bruto como porcentaje de los ingresos. null si no hubo ingresos.
  double? get margenPorcentaje =>
      ingresosCentimos == 0 ? null : margenBrutoCentimos * 100 / ingresosCentimos;

  /// Ticket promedio (ingreso por venta) en céntimos, redondeado al céntimo.
  int? get ticketPromedioCentimos =>
      numeroVentas == 0 ? null : (ingresosCentimos / numeroVentas).round();
}

// ─────────────────────────── Por día ───────────────────────────

/// Ingresos de cada día entre [desde] y [hasta] (incluidos).
/// Los días sin ventas aparecen con 0, para que el gráfico no "salte" días.
Map<DateTime, int> ingresosPorDia(
  Iterable<Venta> ventas, {
  required DateTime desde,
  required DateTime hasta,
}) {
  final resultado = <DateTime, int>{};
  for (var dia = soloFecha(desde);
      !dia.isAfter(soloFecha(hasta));
      dia = DateTime(dia.year, dia.month, dia.day + 1)) {
    resultado[dia] = 0;
  }
  for (final venta in ventasConfirmadas(ventas)) {
    final dia = soloFecha(venta.fecha);
    if (resultado.containsKey(dia)) {
      resultado[dia] = resultado[dia]! + venta.totalCentimos;
    }
  }
  return resultado;
}

// ─────────────────────────── Por producto y categoría ───────────────────────────

/// Totales de un producto dentro de un conjunto de ventas.
class ResumenProducto {
  ResumenProducto({required this.productoId, required this.nombre});

  final String productoId;
  final String nombre;
  int unidades = 0;
  int ingresosCentimos = 0;
  int costoCentimos = 0;

  int get margenCentimos => ingresosCentimos - costoCentimos;
}

/// Unidades, ingresos y costo de cada producto vendido.
/// El nombre es el guardado en la venta más reciente de ese producto.
List<ResumenProducto> resumenPorProducto(Iterable<Venta> ventas) {
  final porId = <String, ResumenProducto>{};
  final ordenadas = ventasConfirmadas(ventas)
    ..sort((a, b) => a.fecha.compareTo(b.fecha));
  for (final venta in ordenadas) {
    for (final d in venta.detalles) {
      final fila = porId.putIfAbsent(
        d.productoId,
        () => ResumenProducto(productoId: d.productoId, nombre: d.nombreProducto),
      );
      fila
        ..unidades += d.cantidad
        ..ingresosCentimos += d.subtotalCentimos
        ..costoCentimos += d.costoCentimos;
    }
  }
  return porId.values.toList();
}

/// Ranking por UNIDADES vendidas (desempate: ingresos y luego nombre).
List<ResumenProducto> rankingPorUnidades(Iterable<Venta> ventas, {int? limite}) {
  final lista = resumenPorProducto(ventas)
    ..sort((a, b) {
      final c = b.unidades.compareTo(a.unidades);
      if (c != 0) return c;
      final i = b.ingresosCentimos.compareTo(a.ingresosCentimos);
      return i != 0 ? i : a.nombre.compareTo(b.nombre);
    });
  return limite == null ? lista : lista.take(limite).toList();
}

/// Ranking por INGRESOS (desempate: unidades y luego nombre).
List<ResumenProducto> rankingPorIngresos(Iterable<Venta> ventas, {int? limite}) {
  final lista = resumenPorProducto(ventas)
    ..sort((a, b) {
      final c = b.ingresosCentimos.compareTo(a.ingresosCentimos);
      if (c != 0) return c;
      final u = b.unidades.compareTo(a.unidades);
      return u != 0 ? u : a.nombre.compareTo(b.nombre);
    });
  return limite == null ? lista : lista.take(limite).toList();
}

/// Ingresos por categoría, de mayor a menor. La categoría es la guardada en
/// cada línea de venta (si luego cambia el producto, el reporte no cambia).
Map<String, int> ingresosPorCategoria(Iterable<Venta> ventas) {
  final totales = <String, int>{};
  for (final venta in ventasConfirmadas(ventas)) {
    for (final d in venta.detalles) {
      totales[d.categoria] = (totales[d.categoria] ?? 0) + d.subtotalCentimos;
    }
  }
  final ordenadas = totales.entries.toList()
    ..sort((a, b) => b.value.compareTo(a.value));
  return {for (final e in ordenadas) e.key: e.value};
}

/// Productos ACTIVOS con stock bajo, del más urgente (menos stock) al menos.
List<Producto> productosStockBajo(Iterable<Producto> productos) =>
    productos.where((p) => p.activo && p.stockBajo).toList()
      ..sort((a, b) {
        final c = a.stock.compareTo(b.stock);
        return c != 0 ? c : a.nombre.compareTo(b.nombre);
      });

// ─────────────────────────── Comparación de períodos ───────────────────────────

/// Variación porcentual de [anterior] a [actual].
/// null si el período anterior es 0 (no se puede dividir entre cero).
double? variacionPorcentual(num actual, num anterior) =>
    anterior == 0 ? null : (actual - anterior) * 100 / anterior;

/// Resultado de comparar un período con el inmediatamente anterior de la
/// misma duración. Ej.: del 15 al 21 → se compara con el 8 al 14.
class ComparacionPeriodos {
  const ComparacionPeriodos({
    required this.desdeActual,
    required this.hastaActual,
    required this.desdeAnterior,
    required this.hastaAnterior,
    required this.actual,
    required this.anterior,
  });

  final DateTime desdeActual;
  final DateTime hastaActual;
  final DateTime desdeAnterior;
  final DateTime hastaAnterior;
  final ResumenVentas actual;
  final ResumenVentas anterior;

  double? get variacionIngresos =>
      variacionPorcentual(actual.ingresosCentimos, anterior.ingresosCentimos);
  double? get variacionVentas =>
      variacionPorcentual(actual.numeroVentas, anterior.numeroVentas);
  double? get variacionUnidades =>
      variacionPorcentual(actual.unidades, anterior.unidades);
  double? get variacionMargen => variacionPorcentual(
      actual.margenBrutoCentimos, anterior.margenBrutoCentimos);
}

ComparacionPeriodos compararPeriodos(
  Iterable<Venta> ventas, {
  required DateTime desde,
  required DateTime hasta,
}) {
  final inicio = soloFecha(desde);
  final fin = soloFecha(hasta);
  final dias = fin.difference(inicio).inDays + 1;
  final finAnterior = DateTime(inicio.year, inicio.month, inicio.day - 1);
  final inicioAnterior =
      DateTime(finAnterior.year, finAnterior.month, finAnterior.day - dias + 1);

  return ComparacionPeriodos(
    desdeActual: inicio,
    hastaActual: fin,
    desdeAnterior: inicioAnterior,
    hastaAnterior: finAnterior,
    actual: ResumenVentas.de(ventasEnRango(ventas, desde: inicio, hasta: fin)),
    anterior: ResumenVentas.de(
        ventasEnRango(ventas, desde: inicioAnterior, hasta: finAnterior)),
  );
}

// ─────────────────────────── Dashboard ───────────────────────────

// Alias: dentro de IndicadoresDashboard, "productosStockBajo" es un campo.
const _listaStockBajo = productosStockBajo;

/// Indicadores de la pantalla de Inicio.
class IndicadoresDashboard {
  const IndicadoresDashboard({
    required this.resumen,
    required this.productosRegistrados,
    required this.productosStockBajo,
  });

  /// Calcula los indicadores del período [desde]–[hasta] (null = todo).
  factory IndicadoresDashboard.calcular({
    required List<Venta> ventas,
    required List<Producto> productos,
    DateTime? desde,
    DateTime? hasta,
  }) {
    return IndicadoresDashboard(
      resumen: ResumenVentas.de(ventasEnRango(ventas, desde: desde, hasta: hasta)),
      productosRegistrados: productos.where((p) => p.activo).length,
      productosStockBajo: _listaStockBajo(productos).length,
    );
  }

  final ResumenVentas resumen;

  /// Productos activos (los desactivados no cuentan).
  final int productosRegistrados;
  final int productosStockBajo;
}
